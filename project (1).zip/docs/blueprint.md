# **App Name**: ShuttleScore

## Core Features:

- Team & Tournament Setup: Initialize a new badminton tournament by setting up 32 doubles teams with their respective names and details, and defining tournament rounds.
- Match Creation & Scheduling: Easily create and schedule matches between the registered doubles teams across different rounds of the tournament.
- Real-time Score Entry: Provide a simple and intuitive interface for officials to input and update scores for live matches, game by game.
- Live Tournament Dashboard: Display a public-facing dashboard with real-time updates of ongoing match scores and current tournament status.
- Dynamic Standings & Leaderboard: Automatically update and display tournament standings and a leaderboard based on recorded match results, reflecting team progress.
- Match Recap Generation Tool: An AI-powered tool that analyzes match scores and generates brief textual recaps or highlights of key moments from completed matches.

## Style Guidelines:

- Color scheme is light, clean, and energetic to evoke the spirit of sport.
- Primary color: A vibrant yet calming blue (#3BA3EB) reflecting movement and clarity, used for key interactive elements and headers.
- Background color: A very light, subtle blue-gray (#F2F5F7), providing a neutral canvas for scores and content.
- Accent color: A striking aqua (#12C1B8) for calls-to-action, active states, and to draw attention to important scores or alerts, providing dynamic contrast to the primary blue.
- Body and headline font: 'Inter', a grotesque-style sans-serif for its modern, objective, and highly legible appearance, ideal for displaying scores and data clearly.
- Use clear, minimalistic line icons related to badminton (shuttlecock, racket, net) and data presentation (trophies, charts, play buttons) for easy recognition.
- Implement a dashboard-like layout with distinct sections for live matches, upcoming schedules, and standings, prioritizing readability and immediate information access for a broad audience.
- Subtle, smooth animations for score updates, team transitions on leaderboards, and interactive elements to provide a polished and responsive user experience.