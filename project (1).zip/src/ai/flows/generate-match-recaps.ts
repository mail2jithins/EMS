'use server';
/**
 * @fileOverview A Genkit flow for generating textual recaps of badminton matches based on scores.
 *
 * - generateMatchRecap - A function that generates a match recap.
 * - GenerateMatchRecapInput - The input type for the generateMatchRecap function.
 * - GenerateMatchRecapOutput - The return type for the generateMatchRecap function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

// External input schema for the wrapper function and UI interaction
const GenerateMatchRecapInputSchema = z.object({
  team1Name: z.string().describe('The name of the first team.'),
  team2Name: z.string().describe('The name of the second team.'),
  gameScores: z.array(
    z.object({
      team1Score: z.number().describe('Score for team 1 in this game.'),
      team2Score: z.number().describe('Score for team 2 in this game.'),
    })
  ).describe('An array of scores for each game played in the match.'),
});
export type GenerateMatchRecapInput = z.infer<typeof GenerateMatchRecapInputSchema>;

// Output schema for the flow and wrapper function
const GenerateMatchRecapOutputSchema = z.object({
  recap: z.string().describe('A brief, engaging textual recap of the badminton match, highlighting key moments and the final outcome.'),
});
export type GenerateMatchRecapOutput = z.infer<typeof GenerateMatchRecapOutputSchema>;

// Internal input schema for the prompt, after pre-processing gameScores into a formatted string
const GenerateMatchRecapPromptInputSchema = z.object({
  team1Name: z.string().describe('The name of the first team.'),
  team2Name: z.string().describe('The name of the second team.'),
  formattedGameScores: z.string().describe('A formatted string listing the scores for each game, e.g., "Game 1: 21-18\nGame 2: 19-21".'),
});

const matchRecapPrompt = ai.definePrompt({
  name: 'matchRecapPrompt',
  input: { schema: GenerateMatchRecapPromptInputSchema },
  output: { schema: GenerateMatchRecapOutputSchema },
  prompt: `You are a professional sports commentator and analyst for a badminton tournament. Your task is to generate a concise, exciting, and engaging match recap based on the provided team names and game scores. Focus on identifying key moments, such as close games, significant point streaks, or dramatic comebacks. Emphasize the competitive spirit and clearly state the final outcome. The recap should be suitable for a public-facing tournament dashboard.

Match Details:
Team 1: {{{team1Name}}}
Team 2: {{{team2Name}}}

Game Scores:
{{{formattedGameScores}}}

Based on these details, provide a compelling and lively match recap.`,
});

const generateMatchRecapFlow = ai.defineFlow(
  {
    name: 'generateMatchRecapFlow',
    inputSchema: GenerateMatchRecapInputSchema,
    outputSchema: GenerateMatchRecapOutputSchema,
  },
  async (input) => {
    // Format the game scores into a string for the prompt to consume
    const formattedGameScores = input.gameScores.map((game, index) =>
      `Game ${index + 1}: ${game.team1Score}-${game.team2Score}`
    ).join('\n');

    const promptInput = {
      team1Name: input.team1Name,
      team2Name: input.team2Name,
      formattedGameScores: formattedGameScores,
    };

    const { output } = await matchRecapPrompt(promptInput);
    // The prompt output directly matches the flow output schema
    return output!;
  }
);

export async function generateMatchRecap(input: GenerateMatchRecapInput): Promise<GenerateMatchRecapOutput> {
  return generateMatchRecapFlow(input);
}
