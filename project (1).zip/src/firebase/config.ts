export const firebaseConfig = {
  "projectId": "studio-3839362272-47f11",
  "appId": "1:944434050199:web:6af5b5c002e46309aca5d2",
  "apiKey": "AIzaSyDi4Yd1rnvjy0ny-MFPvzZCAKzr0ABoeqU",
  "authDomain": "studio-3839362272-47f11.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "944434050199"
};
