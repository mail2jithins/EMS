"use client";

import React, { useState, useEffect, useMemo } from 'react';
import { useTournament } from "@/lib/tournament-context";
import { Trophy, Activity, Zap, ArrowLeft, Layers, CalendarClock, Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn, sortTeams } from "@/lib/utils";
import Link from 'next/link';
import { GroupLetter, Match } from '@/lib/types';

type TVView = 'matches' | 'standings' | 'knockout' | 'champion';

export default function TVDashboard() {
  const { state } = useTournament();
  const [view, setView] = useState<TVView>('matches');
  
  const liveMatches = state.matches.filter(m => m.status === 'live');
  const upcomingMatches = state.matches.filter(m => m.status === 'scheduled').slice(0, 4);
  
  const recentMatches = useMemo(() => {
    return [...state.matches]
      .filter(m => m.status === 'completed')
      .sort((a, b) => {
        if (a.stage !== b.stage) {
          return a.stage === 'knockout' ? -1 : 1;
        }
        
        const getPriority = (m: Match) => {
          if (m.stage === 'round-robin') return 0;
          const code = (m.roundName || '').toUpperCase();
          if (code.startsWith('F')) return 100;
          if (code.startsWith('TP')) return 90;
          if (code.startsWith('S')) return 80;
          if (code.startsWith('Q')) return 70;
          if (code.startsWith('PQ')) return 60;
          return 50;
        };

        const pA = getPriority(a);
        const pB = getPriority(b);
        if (pA !== pB) return pB - pA;

        return (a.roundName || '').localeCompare(b.roundName || '', undefined, { numeric: true });
      })
      .slice(0, 8);
  }, [state.matches]);

  const hasKnockout = state.matches.some(m => m.stage === 'knockout');

  const finalMatch = useMemo(() => 
    state.matches.find(m => m.stage === 'knockout' && (m.roundName === 'F' || m.roundName === 'Final')),
  [state.matches]);

  const isTournamentOver = finalMatch?.status === 'completed';

  const championTeam = useMemo(() => {
    if (!finalMatch || finalMatch.status !== 'completed') return null;
    const setsWon1 = finalMatch.gameScores.filter(g => Number(g.team1Score || 0) > Number(g.team2Score || 0)).length;
    const setsWon2 = finalMatch.gameScores.filter(g => Number(g.team2Score || 0) > Number(g.team1Score || 0)).length;
    const championId = setsWon1 > setsWon2 ? finalMatch.team1Id : finalMatch.team2Id;
    return state.teams.find(t => t.id === championId);
  }, [finalMatch, state.teams]);

  const roundGroups = [
    { 
      label: 'Round of 16', 
      codes: ['PQ1', 'PQ2', 'PQ3', 'PQ4', 'PQ5', 'PQ6', 'PQ7', 'PQ8'],
      aliases: ['PRE-QUARTER', 'ROUND OF 16', 'P-QUARTER']
    },
    { 
      label: 'Quarter-Final', 
      codes: ['Q1', 'Q2', 'Q3', 'Q4'],
      aliases: ['QUARTER', 'QUARTER-FINAL', 'QUARTERS']
    },
    { 
      label: 'Semi-Final', 
      codes: ['S1', 'S2'],
      aliases: ['SEMI', 'SEMI-FINAL', 'SEMIS']
    },
    { 
      label: '3rd Place', 
      codes: ['TP'],
      aliases: ['3RD PLACE', 'BRONZE']
    },
    { 
      label: 'Final', 
      codes: ['F'],
      aliases: ['FINAL', 'GOLD', 'CHAMPIONSHIP']
    }
  ];

  const normalize = (s: string) => s.trim().toUpperCase();

  useEffect(() => {
    const views: TVView[] = ['matches', 'standings'];
    if (hasKnockout) views.push('knockout');
    if (isTournamentOver) views.push('champion');

    const interval = setInterval(() => {
      setView(currentView => {
        const currentIndex = views.indexOf(currentView);
        const nextIndex = (currentIndex + 1) % views.length;
        return views[nextIndex];
      });
    }, 15000);

    return () => clearInterval(interval);
  }, [hasKnockout, isTournamentOver]);

  return (
    <div className="h-[100dvh] w-full bg-zinc-950 text-white p-2 sm:p-4 font-body flex flex-col overflow-hidden max-w-full">
      <header className="flex-shrink-0 flex items-center justify-between mb-1 sm:mb-2 border-b border-zinc-900 pb-1 sm:pb-2 min-w-0">
        <div className="flex items-center gap-3 min-w-0">
          <Link href="/" className="shrink-0">
             <ArrowLeft className="h-4 w-4 sm:h-5 sm:w-5 text-zinc-600 hover:text-white transition-colors" />
          </Link>
          <div className="bg-primary p-1 rounded-lg shrink-0">
            <Trophy className="text-white h-5 w-5 sm:h-7 sm:w-7" />
          </div>
          <div className="min-w-0">
            <h1 className="text-lg sm:text-3xl font-black tracking-tighter flex items-center gap-2 truncate">
              EMS <span className="text-secondary">BADMINTON</span> 
              <span className="text-zinc-600 font-bold text-xs sm:text-xl hidden md:inline ml-2 truncate">
                • {view === 'matches' ? 'LIVE ACTION' : view === 'standings' ? 'STANDINGS' : view === 'champion' ? 'CONGRATULATIONS' : 'KNOCKOUT'}
              </span>
            </h1>
          </div>
        </div>
        
        {view !== 'champion' && (
          <div className="flex items-center gap-4 shrink-0">
            {liveMatches.length > 0 && (
              <div className="flex items-center gap-1 sm:gap-2 bg-red-500/10 text-red-500 px-2 sm:px-3 py-0.5 sm:py-1 rounded-full border border-red-500/20">
                <Activity className="h-2 w-2 sm:h-3 w-3 animate-pulse" />
                <span className="font-bold text-[10px] sm:text-base tracking-widest">{liveMatches.length} LIVE</span>
              </div>
            )}
            <div className="text-right hidden sm:block">
              <div className="text-[10px] font-black text-zinc-600 uppercase tracking-widest leading-none mb-0.5">Finished</div>
              <div className="text-lg font-black leading-none text-primary">{state.matches.filter(m => m.status === 'completed').length}</div>
            </div>
          </div>
        )}
      </header>

      <main className="flex-1 min-h-0 w-full overflow-hidden">
        {view === 'matches' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-2 h-full min-h-0 w-full">
            <div className="flex flex-col h-full min-h-0 overflow-hidden min-w-0">
              <h2 className="text-[10px] sm:text-sm font-black text-zinc-600 uppercase flex items-center gap-2 flex-shrink-0 mb-1">
                <Activity className="h-3 w-3 sm:h-4 sm:w-4 text-secondary" /> Ongoing
              </h2>
              <div className="flex-1 overflow-y-auto scrollbar-hide space-y-2 pr-1 min-h-0">
                {liveMatches.length > 0 ? (
                  liveMatches.map(match => (
                    <TVMatchCard key={match.id} match={match} teams={state.teams} isLive />
                  ))
                ) : (
                  <div className="space-y-2">
                    <h3 className="text-[9px] sm:text-xs font-black text-zinc-500 uppercase flex items-center gap-2 mt-2">
                      <CalendarClock className="h-3 w-3" /> Upcoming Schedule
                    </h3>
                    {upcomingMatches.length > 0 ? (
                      upcomingMatches.map(match => (
                        <TVMatchCard key={match.id} match={match} teams={state.teams} />
                      ))
                    ) : (
                      <div className="h-full py-8 sm:py-12 flex flex-col items-center justify-center border-2 border-dashed border-zinc-900 rounded-3xl opacity-30">
                        <Zap className="h-6 w-6 sm:h-8 sm:w-8 mb-2" />
                        <p className="text-sm sm:text-base font-bold italic text-center uppercase tracking-widest">Awaiting Next Matches</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            <div className="flex flex-col h-full min-h-0 overflow-hidden min-w-0">
              <h2 className="text-[10px] sm:text-sm font-black text-zinc-600 uppercase flex-shrink-0 mb-1">Recent Results</h2>
              <div className="flex-1 overflow-y-auto scrollbar-hide space-y-1.5 pr-1 min-h-0">
                {recentMatches.map(match => (
                  <TVMatchCard key={match.id} match={match} teams={state.teams} />
                ))}
                {recentMatches.length === 0 && (
                  <div className="h-full flex flex-col items-center justify-center border border-zinc-900 rounded-3xl opacity-10">
                    <p className="text-zinc-700 italic">No matches finished.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {view === 'standings' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2 h-full min-h-0 w-full overflow-hidden">
            {(['A', 'B', 'C', 'D'] as GroupLetter[]).map(group => (
               <div key={group} className="flex flex-col h-full min-h-0 overflow-hidden max-h-full min-w-0">
                 <h2 className="text-base sm:text-lg font-black text-secondary border-b-2 border-secondary/20 mb-1 flex-shrink-0">GROUP {group}</h2>
                 <div className="flex-1 overflow-y-auto scrollbar-hide space-y-1 pr-1 min-h-0">
                    {sortTeams(state.teams.filter(t => t.group === group), state.matches)
                      .slice(0, 10)
                      .map((team, idx) => (
                        <div key={team.id} className="bg-zinc-900/40 p-1 rounded flex items-center justify-between border border-zinc-800/50 min-w-0">
                          <div className="flex items-center gap-1.5 overflow-hidden min-w-0">
                            <span className={cn(
                              "text-xs font-black w-3 shrink-0",
                              idx < 4 ? "text-secondary" : "text-zinc-800"
                            )}>{idx + 1}</span>
                            <div className="overflow-hidden min-w-0 flex-1">
                              <div className="text-[10px] sm:text-[11px] font-bold truncate leading-tight uppercase">{team.name}</div>
                              <div className="text-[7px] sm:text-[8px] text-zinc-600 truncate leading-none">{team.player1} & {team.player2}</div>
                            </div>
                          </div>
                          <div className="text-right shrink-0 ml-1.5">
                             <div className="text-[10px] sm:text-xs font-black text-primary leading-tight">{team.wins}W</div>
                             <div className="text-[7px] text-zinc-600 font-bold uppercase leading-none">{team.points} pts</div>
                          </div>
                        </div>
                      ))}
                 </div>
               </div>
            ))}
          </div>
        )}

        {view === 'knockout' && (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-1 sm:gap-1.5 h-full min-h-0 w-full overflow-hidden">
            {roundGroups.map(round => {
              const matches = state.matches.filter(m => {
                if (m.stage !== 'knockout' || !m.roundName) return false;
                const normalizedName = normalize(m.roundName);
                const matchesCode = round.codes.some(c => normalize(c) === normalizedName);
                const matchesAlias = round.aliases.some(a => normalizedName.includes(a));
                return matchesCode || matchesAlias;
              }).sort((a, b) => (a.roundName || '').localeCompare(b.roundName || '', undefined, { numeric: true }));
              
              return (
                <div key={round.label} className="flex flex-col h-full min-h-0 overflow-hidden max-h-full min-w-0">
                  <h2 className="text-[9px] sm:text-[10px] font-black text-secondary border-b border-secondary/20 mb-0.5 sm:mb-1 flex items-center gap-1 uppercase tracking-tighter flex-shrink-0">
                    <Layers className="h-2 w-2 sm:h-3 sm:w-3 shrink-0" /> <span className="truncate">{round.label === 'Round of 16' ? 'R16' : round.label}</span>
                  </h2>
                  <div className="flex-1 overflow-y-auto scrollbar-hide space-y-0.5 sm:space-y-1 pr-0.5 min-h-0">
                    {matches.map(m => (
                      <TVKnockoutMatchCard key={m.id} match={m} teams={state.teams} />
                    ))}
                    {matches.length === 0 && <div className="text-zinc-900 text-[7px] sm:text-[8px] italic border border-dashed border-zinc-900 rounded-lg h-6 sm:h-8 flex items-center justify-center uppercase">TBD</div>}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {view === 'champion' && (
          <div className="h-full w-full flex flex-col items-center justify-center animate-in fade-in zoom-in duration-1000 relative">
            <div className="relative z-10 flex flex-col items-center text-center max-w-4xl px-4">
              <div className="mb-4 sm:mb-6 p-4 sm:p-6 bg-yellow-500/10 rounded-full border-4 border-yellow-500/20">
                <Trophy className="h-16 w-16 sm:h-32 sm:w-32 text-yellow-500 animate-bounce" />
              </div>
              
              <div className="space-y-3 sm:space-y-6">
                <div className="space-y-1 sm:space-y-2">
                  <Badge className="bg-yellow-500 text-black font-black px-3 sm:px-6 py-0.5 sm:py-1 text-xs sm:text-lg rounded-full uppercase italic tracking-widest">
                    Tournament Champions
                  </Badge>
                  <h2 className="text-3xl sm:text-7xl lg:text-8xl font-black text-white uppercase italic tracking-tighter leading-none px-2">
                    {championTeam?.name || 'THE WINNERS'}
                  </h2>
                </div>
                
                <div className="bg-primary/20 border-2 border-primary/40 px-4 sm:px-12 py-2 sm:py-6 rounded-xl sm:rounded-3xl backdrop-blur-xl inline-block">
                  <p className="text-base sm:text-3xl text-zinc-300 font-bold uppercase tracking-tight">
                    {championTeam?.player1} <span className="text-primary mx-1 sm:mx-2">&</span> {championTeam?.player2}
                  </p>
                </div>
              </div>

              <div className="mt-6 sm:mt-16">
                <p className="text-lg sm:text-5xl font-black text-zinc-600 uppercase tracking-widest sm:tracking-[0.3em] animate-pulse italic leading-tight">
                  Thank you All from Team EMS
                </p>
              </div>
            </div>
            
            <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-900/50 to-zinc-950 pointer-events-none" />
          </div>
        )}
      </main>
      
      <footer className="flex-shrink-0 mt-1 sm:mt-2 pt-0.5 border-t border-zinc-900 flex justify-between items-center text-[8px] sm:text-[9px] font-bold text-zinc-700 uppercase tracking-widest overflow-hidden min-w-0">
        <div className="truncate mr-4">EMS Badminton Dashboard</div>
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <div className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-secondary" /> Sets
          </div>
          <div className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-primary" /> Points
          </div>
        </div>
      </footer>

      <style jsx global>{`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}

function TVMatchCard({ match, teams, isLive = false }: { match: Match, teams: any[], isLive?: boolean }) {
  const t1 = teams.find(t => t.id === match.team1Id);
  const t2 = teams.find(t => t.id === match.team2Id);
  
  const isCompleted = match.status === 'completed';
  const setsWon1 = match.gameScores.filter((g: any) => Number(g.team1Score || 0) > Number(g.team2Score || 0)).length;
  const setsWon2 = match.gameScores.filter((g: any) => Number(g.team2Score || 0) > Number(g.team1Score || 0)).length;
  
  const team1Won = isCompleted && setsWon1 > setsWon2;
  const team2Won = isCompleted && setsWon2 > setsWon1;

  const isMultiGame = match.gameScores.length > 1;
  const activeGameIndex = match.activeGameIndex ?? 0;
  const activeGame = match.gameScores[activeGameIndex] || match.gameScores[0];
  
  const score1 = activeGame?.team1Score ?? 0;
  const score2 = activeGame?.team2Score ?? 0;

  const team1LastPoint = isLive && match.lastPointTeamId === match.team1Id;
  const team2LastPoint = isLive && match.lastPointTeamId === match.team2Id;

  const gameBreakdown = match.gameScores.map(g => `${g.team1Score}-${g.team2Score}`).join(', ');

  return (
    <Card className={cn(
      "border-none overflow-hidden transition-all duration-300 min-w-0",
      isLive ? "bg-zinc-900 ring-1 ring-secondary shadow-lg" : "bg-zinc-900/30 opacity-90 border border-zinc-900/50"
    )}>
      <CardContent className="p-1.5 sm:p-3">
        <div className="flex items-center justify-between mb-0.5 sm:mb-1">
          <Badge variant="outline" className="border-zinc-800 text-zinc-600 text-[7px] sm:text-[8px] py-0 px-1 uppercase">
            CRT {match.court} {match.stage === 'knockout' ? `• ${match.roundName}` : `• GRP ${match.group}`}
          </Badge>
          {isLive && <Badge className="bg-red-600 text-white font-black animate-pulse px-1 py-0 text-[7px] sm:text-[8px]">LIVE - GAME {activeGameIndex + 1}</Badge>}
          {!isLive && match.status === 'scheduled' && <Badge variant="secondary" className="bg-zinc-800 text-zinc-400 font-black px-1 py-0 text-[7px] sm:text-[8px]">UPCOMING</Badge>}
          {isCompleted && !isLive && <Badge className="bg-zinc-800 text-zinc-500 font-black px-1 py-0 text-[7px] sm:text-[8px]">FINAL RESULT</Badge>}
        </div>

        <div className="flex items-center justify-between gap-1 sm:gap-2 min-w-0">
          <div className={cn(
            "flex-1 text-right overflow-hidden min-w-0 transition-all duration-300",
            (isCompleted && team1Won) || team1LastPoint ? "text-secondary font-black scale-105" : ""
          )}>
            <h3 className="text-sm sm:text-lg font-black truncate leading-tight uppercase">{t1?.name || 'TBD'}</h3>
            <p className="text-[7px] sm:text-[8px] text-zinc-600 font-bold truncate tracking-tight leading-none">{t1?.player1} & {t1?.player2}</p>
          </div>
          
          <div className="flex items-center gap-1 sm:gap-4 shrink-0 px-0.5">
             {isMultiGame && (
               <div className="flex flex-col items-center">
                 <span className="text-[6px] sm:text-[8px] text-zinc-600 font-black leading-none mb-0.5 uppercase tracking-tighter">Sets</span>
                 <span className="text-xs sm:text-xl font-black text-secondary leading-none">{setsWon1}</span>
               </div>
             )}

             <div className="flex items-center gap-1 sm:gap-2 bg-black/40 px-1.5 sm:px-2 py-0.5 sm:py-1 rounded-lg border border-zinc-800">
               <div className={cn("text-xl sm:text-5xl font-black min-w-[30px] sm:min-w-[60px] text-center", (isLive || team1Won) ? "text-primary" : "text-white")}>
                 {score1}
               </div>
               <div className="text-[8px] sm:text-[10px] font-black text-zinc-800">VS</div>
               <div className={cn("text-xl sm:text-5xl font-black min-w-[30px] sm:min-w-[60px] text-center", (isLive || team2Won) ? "text-primary" : "text-white")}>
                 {score2}
               </div>
             </div>

             {isMultiGame && (
               <div className="flex flex-col items-center">
                 <span className="text-[6px] sm:text-[8px] text-zinc-600 font-black leading-none mb-0.5 uppercase tracking-tighter">Sets</span>
                 <span className="text-xs sm:text-xl font-black text-secondary leading-none">{setsWon2}</span>
               </div>
             )}
          </div>

          <div className={cn(
            "flex-1 overflow-hidden min-w-0 transition-all duration-300",
            (isCompleted && team2Won) || team2LastPoint ? "text-secondary font-black scale-105" : ""
          )}>
            <h3 className="text-sm sm:text-lg font-black truncate leading-tight uppercase">{t2?.name || 'TBD'}</h3>
            <p className="text-[7px] sm:text-[8px] text-zinc-600 font-bold truncate tracking-tight leading-none">{t2?.player1} & {t2?.player2}</p>
          </div>
        </div>
        
        {isMultiGame && (
          <div className="mt-1 flex items-center justify-center gap-2 border-t border-zinc-900 pt-0.5 sm:pt-1.5">
            <span className="text-[6px] sm:text-[7px] font-black text-zinc-700 uppercase tracking-widest">History:</span>
            <span className="text-[8px] sm:text-[9px] font-mono font-bold text-zinc-500 italic">({gameBreakdown})</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function TVKnockoutMatchCard({ match, teams }: { match: Match, teams: any[] }) {
  const t1 = teams.find(t => t.id === match.team1Id);
  const t2 = teams.find(t => t.id === match.team2Id);
  const isLive = match.status === 'live';
  const isCompleted = match.status === 'completed';

  const setsWon1 = match.gameScores.filter((g: any) => Number(g.team1Score || 0) > Number(g.team2Score || 0)).length;
  const setsWon2 = match.gameScores.filter((g: any) => Number(g.team2Score || 0) > Number(g.team1Score || 0)).length;

  const activeGameIndex = match.activeGameIndex ?? 0;
  const activeGame = match.gameScores[activeGameIndex] || match.gameScores[0];

  const score1 = isCompleted ? setsWon1 : (activeGame?.team1Score ?? 0);
  const score2 = isCompleted ? setsWon2 : (activeGame?.team2Score ?? 0);

  const gameBreakdown = match.gameScores.map(g => `${g.team1Score}-${g.team2Score}`).join(',');

  return (
    <div className={cn(
      "bg-zinc-900/50 border p-0.5 rounded transition-all min-w-0",
      isLive ? "border-secondary ring-1 ring-secondary/30 shadow-md animate-pulse" : "border-zinc-900"
    )}>
      <div className="flex items-center justify-between mb-0 px-0.5">
        <span className="text-[5px] sm:text-[6px] font-bold text-zinc-700 uppercase">{match.roundName}</span>
        {isLive && <span className="text-[5px] sm:text-[6px] font-black text-secondary uppercase">Live G{activeGameIndex + 1}</span>}
        {isCompleted && !isLive && <span className="text-[5px] sm:text-[6px] font-black text-zinc-600 uppercase">Final</span>}
      </div>
      <div className="space-y-0 min-w-0 px-0.5">
        <div className={cn(
          "flex justify-between items-center text-[7px] sm:text-[8px] min-w-0 leading-tight",
          isCompleted && setsWon1 > setsWon2 ? "text-primary font-black" : "text-zinc-400"
        )}>
          <span className="truncate pr-0.5 uppercase min-w-0">{t1?.name || 'TBD'}</span>
          <span className="font-mono text-[7px] sm:text-[9px] shrink-0">{score1}</span>
        </div>
        <div className={cn(
          "flex justify-between items-center text-[7px] sm:text-[8px] min-w-0 leading-tight",
          isCompleted && setsWon2 > setsWon1 ? "text-primary font-black" : "text-zinc-400"
        )}>
          <span className="truncate pr-0.5 uppercase min-w-0">{t2?.name || 'TBD'}</span>
          <span className="font-mono text-[7px] sm:text-[9px] shrink-0">{score2}</span>
        </div>
      </div>
      {(isLive || isCompleted) && match.gameScores.length > 1 && (
        <div className="mt-0.5 border-t border-zinc-900/30 text-center leading-none">
          <span className="text-[5px] sm:text-[6px] font-mono text-zinc-700 italic">({gameBreakdown})</span>
        </div>
      )}
    </div>
  );
}
