"use client";

import React, { useState, useEffect, useMemo } from 'react';
import { useTournament } from "@/lib/tournament-context";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Play, Square, Activity, Loader2, ChevronLeft, ChevronRight, CheckCircle2 } from "lucide-react";
import Link from 'next/link';
import { useToast } from "@/hooks/use-toast";
import { useUser } from '@/firebase';
import { useRouter } from 'next/navigation';
import { cn } from "@/lib/utils";

export default function ScoringPage() {
  const { state, loading, userRole, userEmail, updateMatchScore, setMatchStatus, setActiveGame, generateRecap } = useTournament();
  const { user, loading: authLoading } = useUser();
  const router = useRouter();
  const { toast } = useToast();
  const [selectedMatchId, setSelectedMatchId] = useState<string | null>(null);
  const [activeGameIndex, setActiveGameIndex] = useState(0);
  const [generatingRecap, setGeneratingRecap] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login');
    }
  }, [user, authLoading, router]);

  const isAdmin = userRole === 'admin';
  const isScorekeeper = userRole === 'scorekeeper';
  const canScore = isAdmin || isScorekeeper;

  const assignedCourt = useMemo(() => {
    if (isAdmin) return null;
    if (!userEmail) return null;
    const match = userEmail.match(/scorekeeper(\d)@test\.com/);
    return match ? match[1] : null;
  }, [userEmail, isAdmin]);

  const activeMatches = useMemo(() => {
    let matches = state.matches.filter(m => m.status !== 'completed');
    if (assignedCourt) {
      matches = matches.filter(m => m.court === assignedCourt);
    }
    return matches;
  }, [state.matches, assignedCourt]);

  const selectedMatch = state.matches.find(m => m.id === selectedMatchId);

  // Sync internal state if match's activeGameIndex changes from elsewhere
  useEffect(() => {
    if (selectedMatch && selectedMatch.activeGameIndex !== undefined) {
      setActiveGameIndex(selectedMatch.activeGameIndex);
    }
  }, [selectedMatch?.id, selectedMatch?.activeGameIndex]);

  // If still checking auth or tournament data, show loader
  if (authLoading || loading || (user && userRole === null)) {
    return (
      <div className="h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Strict role-based rendering guard
  if (!canScore) {
    return (
      <div className="h-screen flex items-center justify-center p-4 text-center">
        <div className="space-y-4">
          <Activity className="mx-auto h-12 w-12 text-destructive opacity-20" />
          <h2 className="text-xl font-bold">Access Denied</h2>
          <p className="text-muted-foreground text-sm">Official authorization is required to access the scoring console.</p>
          <Button onClick={() => router.push('/')} variant="outline" className="w-full">Dashboard</Button>
        </div>
      </div>
    );
  }

  const handleScoreChange = (teamIdx: 1 | 2, increment: number) => {
    if (!selectedMatch) return;

    if (assignedCourt && selectedMatch.court !== assignedCourt) {
      toast({ variant: "destructive", title: "Unauthorized", description: `You are only authorized to score Court ${assignedCourt}.` });
      return;
    }

    const game = selectedMatch.gameScores[activeGameIndex];
    const newScore = teamIdx === 1 
      ? Math.max(0, Number(game.team1Score || 0) + increment) 
      : Math.max(0, Number(game.team2Score || 0) + increment);

    updateMatchScore(
      selectedMatch.id, 
      teamIdx === 1 ? newScore : Number(game.team1Score || 0), 
      teamIdx === 2 ? newScore : Number(game.team2Score || 0), 
      activeGameIndex
    );
  };

  const handleGameTabClick = (idx: number) => {
    setActiveGameIndex(idx);
    if (selectedMatchId) {
      setActiveGame(selectedMatchId, idx); // Broadcasters see what the official sees
    }
  };

  const handleCompleteMatch = async (matchId: string) => {
    setMatchStatus(matchId, 'completed');
    toast({ title: "Match Completed", description: "Final results locked." });
    
    setGeneratingRecap(true);
    await generateRecap(matchId);
    setGeneratingRecap(false);
    setSelectedMatchId(null);
  };

  return (
    <div className="min-h-screen bg-background font-body">
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon"><ArrowLeft className="h-5 w-5" /></Button>
            </Link>
            <h1 className="text-xl font-bold flex items-center gap-2">
              <Activity className="text-secondary h-5 w-5" /> Official Scoring
            </h1>
          </div>
          <div className="flex items-center gap-4">
            {assignedCourt && (
              <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20">
                COURT {assignedCourt} ONLY
              </Badge>
            )}
            <Badge variant="outline" className="hidden sm:block truncate max-w-[150px]">{userEmail}</Badge>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {!selectedMatchId ? (
          <div className="max-w-4xl mx-auto space-y-6">
            <h2 className="text-2xl font-bold">
              {assignedCourt ? `Active Matches for Court ${assignedCourt}` : "Select Match to Score"}
            </h2>
            <div className="grid gap-4">
              {activeMatches.map(match => {
                const t1 = state.teams.find(t => t.id === match.team1Id);
                const t2 = state.teams.find(t => t.id === match.team2Id);
                return (
                  <Card key={match.id} className="hover:border-primary transition-all cursor-pointer group" onClick={() => {
                    setSelectedMatchId(match.id);
                    setActiveGameIndex(match.activeGameIndex || 0);
                  }}>
                    <CardContent className="p-6 flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant={match.status === 'live' ? 'secondary' : 'outline'}>
                            {match.status === 'live' ? 'LIVE' : 'SCHEDULED'}
                          </Badge>
                          <span className="text-xs font-bold text-muted-foreground uppercase">
                            Court {match.court} • {match.gameScores.length} Games
                          </span>
                        </div>
                        <div className="flex items-center gap-4 text-xl font-bold">
                          <span>{t1?.name}</span>
                          <span className="text-sm font-light text-muted-foreground">vs</span>
                          <span>{t2?.name}</span>
                        </div>
                      </div>
                      <Button variant="outline" className="group-hover:bg-primary group-hover:text-white transition-all">Start Scoring</Button>
                    </CardContent>
                  </Card>
                );
              })}
              {activeMatches.length === 0 && (
                <div className="text-center py-20 bg-muted/20 rounded-xl border-dashed border-2">
                  <Activity className="mx-auto h-12 w-12 text-muted-foreground opacity-20 mb-4" />
                  <p className="text-muted-foreground">No active matches found {assignedCourt ? `for Court ${assignedCourt}` : ""}.</p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="max-w-3xl mx-auto">
            <Button variant="ghost" onClick={() => setSelectedMatchId(null)} className="mb-6"><ChevronLeft className="mr-2 h-4 w-4" /> Back to matches</Button>
            {selectedMatch && (
              <div className="space-y-6">
                <Card className="border-none shadow-xl overflow-hidden bg-white">
                  <div className="bg-primary p-4 text-white flex justify-between items-center">
                    <div className="flex items-center gap-3">
                      <div>
                        <h3 className="font-bold text-lg">MATCH CONSOLE</h3>
                        <p className="text-xs opacity-80 uppercase font-black">
                          {selectedMatch.stage === 'knockout' ? selectedMatch.roundName : `Group ${selectedMatch.group}`} • Court {selectedMatch.court}
                        </p>
                      </div>
                    </div>
                    {selectedMatch.status === 'scheduled' ? (
                      <Button variant="secondary" onClick={() => setMatchStatus(selectedMatch.id, 'live')}>
                        <Play className="mr-2 h-4 w-4" /> START MATCH
                      </Button>
                    ) : (
                      <div className="flex items-center gap-2">
                        <Badge className="bg-white text-primary animate-pulse">LIVE</Badge>
                        <Button variant="destructive" size="sm" onClick={() => handleCompleteMatch(selectedMatch.id)}>
                          <Square className="mr-2 h-3 w-3" /> END MATCH
                        </Button>
                      </div>
                    )}
                  </div>
                  
                  {selectedMatch.status !== 'scheduled' && (
                    <div className="bg-muted/30 p-2 flex justify-center gap-2 border-b">
                      {selectedMatch.gameScores.map((_, idx) => (
                        <Button 
                          key={idx} 
                          variant={activeGameIndex === idx ? "default" : "outline"}
                          size="sm"
                          onClick={() => handleGameTabClick(idx)}
                          className="h-8 min-w-[80px]"
                        >
                          Game {idx + 1}
                        </Button>
                      ))}
                    </div>
                  )}

                  <CardContent className="p-8">
                    <div className="grid grid-cols-1 gap-12">
                      <ScoringControl 
                        team={state.teams.find(t => t.id === selectedMatch.team1Id)!} 
                        score={Number(selectedMatch.gameScores[activeGameIndex]?.team1Score || 0)}
                        onIncrement={() => handleScoreChange(1, 1)}
                        onDecrement={() => handleScoreChange(1, -1)}
                        color="text-primary"
                        disabled={selectedMatch.status === 'scheduled'}
                      />
                      <div className="h-px bg-border flex items-center justify-center relative">
                        <span className="bg-white px-4 text-xs font-black text-muted-foreground uppercase tracking-widest">Game {activeGameIndex + 1} Score</span>
                      </div>
                      <ScoringControl 
                        team={state.teams.find(t => t.id === selectedMatch.team2Id)!} 
                        score={Number(selectedMatch.gameScores[activeGameIndex]?.team2Score || 0)}
                        onIncrement={() => handleScoreChange(2, 1)}
                        onDecrement={() => handleScoreChange(2, -1)}
                        color="text-secondary"
                        disabled={selectedMatch.status === 'scheduled'}
                      />
                    </div>
                  </CardContent>
                </Card>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <Card className="bg-white">
                     <CardHeader className="py-3"><CardTitle className="text-sm">Sets Overview</CardTitle></CardHeader>
                     <CardContent className="space-y-2">
                        {selectedMatch.gameScores.map((g, idx) => {
                          const winner = Number(g.team1Score || 0) > Number(g.team2Score || 0) ? 1 : Number(g.team2Score || 0) > Number(g.team1Score || 0) ? 2 : null;
                          return (
                            <div key={idx} className="flex items-center justify-between text-xs p-2 rounded bg-muted/20">
                              <span>Game {idx + 1}</span>
                              <div className="flex gap-4 font-mono">
                                <span className={cn(winner === 1 && "text-primary font-bold")}>{g.team1Score}</span>
                                <span className="text-muted-foreground">-</span>
                                <span className={cn(winner === 2 && "text-secondary font-bold")}>{g.team2Score}</span>
                              </div>
                            </div>
                          );
                        })}
                     </CardContent>
                   </Card>

                   <Card className="bg-white flex flex-col justify-center items-center p-6 text-center space-y-2">
                      <Activity className="h-8 w-8 text-primary opacity-20" />
                      <p className="text-xs text-muted-foreground uppercase font-bold tracking-widest">Match Progress</p>
                      <div className="text-2xl font-black">
                        {selectedMatch.gameScores.filter(g => Number(g.team1Score || 0) > Number(g.team2Score || 0)).length} - {selectedMatch.gameScores.filter(g => Number(g.team2Score || 0) > Number(g.team1Score || 0)).length}
                      </div>
                      <p className="text-[10px] text-muted-foreground">Sets won by each team</p>
                   </Card>
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

function ScoringControl({ team, score, onIncrement, onDecrement, color, disabled }: { 
  team: any, score: number, onIncrement: () => void, onDecrement: () => void, color: string, disabled: boolean 
}) {
  return (
    <div className={cn("flex flex-col items-center gap-6", disabled && "opacity-50 grayscale")}>
      <div className="text-center">
        <h4 className="text-2xl font-black">{team?.name}</h4>
        <p className="text-sm text-muted-foreground">{team?.player1} & {team?.player2}</p>
      </div>
      <div className="flex items-center gap-8">
        <Button variant="outline" size="icon" className="h-16 w-16 rounded-full border-2" onClick={onDecrement} disabled={disabled}>
          <ChevronLeft className="h-8 w-8" />
        </Button>
        <span className={`text-8xl font-black tabular-nums w-40 text-center ${color}`}>
          {score}
        </span>
        <Button variant="outline" size="icon" className="h-16 w-16 rounded-full border-2 bg-muted/20" onClick={onIncrement} disabled={disabled}>
          <ChevronRight className="h-8 w-8" />
        </Button>
      </div>
    </div>
  );
}
