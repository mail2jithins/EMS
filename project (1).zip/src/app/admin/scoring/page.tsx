"use client";

import React, { useState, useEffect, useMemo } from 'react';
import { useTournament } from "@/lib/tournament-context";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Play, Square, RefreshCcw, Sparkles, ChevronLeft, ChevronRight, Activity, Loader2, ShieldAlert } from "lucide-react";
import Link from 'next/link';
import { useToast } from "@/hooks/use-toast";
import { useUser } from '@/firebase';
import { useRouter } from 'next/navigation';

export default function ScoringPage() {
  const { state, loading, userRole, userEmail, updateMatchScore, setMatchStatus, generateRecap } = useTournament();
  const { user, loading: authLoading } = useUser();
  const router = useRouter();
  const { toast } = useToast();
  const [selectedMatchId, setSelectedMatchId] = useState<string | null>(null);
  const [generatingRecap, setGeneratingRecap] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login');
    }
  }, [user, authLoading, router]);

  const isAdmin = userRole === 'admin';
  const canScore = isAdmin || userRole === 'scorekeeper';

  // Determine assigned court for numbered scorekeepers
  const assignedCourt = useMemo(() => {
    if (isAdmin) return null; // Admins can score all courts
    if (!userEmail) return null;
    const match = userEmail.match(/scorekeeper(\d)@test\.com/);
    return match ? match[1] : null;
  }, [userEmail, isAdmin]);

  const activeMatches = useMemo(() => {
    let matches = state.matches.filter(m => m.status !== 'completed');
    if (assignedCourt) {
      matches = matches.filter(m => m.court === assignedCourt);
    }
    return matches;
  }, [state.matches, assignedCourt]);

  const selectedMatch = state.matches.find(m => m.id === selectedMatchId);

  const handleScoreChange = (matchId: string, teamIdx: 1 | 2, increment: number, gameIdx: number) => {
    if (!canScore) return;
    const match = state.matches.find(m => m.id === matchId);
    if (!match) return;

    // Extra client-side safety check for court assignment
    if (assignedCourt && match.court !== assignedCourt) {
      toast({ variant: "destructive", title: "Unauthorized", description: `You are only authorized to score Court ${assignedCourt}.` });
      return;
    }

    const game = match.gameScores[gameIdx];
    const newScore = teamIdx === 1 
      ? Math.max(0, game.team1Score + increment) 
      : Math.max(0, game.team2Score + increment);

    updateMatchScore(
      matchId, 
      teamIdx === 1 ? newScore : game.team1Score, 
      teamIdx === 2 ? newScore : game.team2Score, 
      gameIdx
    );
  };

  const handleCompleteMatch = async (matchId: string) => {
    if (!canScore) return;
    setMatchStatus(matchId, 'completed');
    toast({ title: "Match Completed", description: "The scores have been finalized and standings updated." });
    
    setGeneratingRecap(true);
    await generateRecap(matchId);
    setGeneratingRecap(false);
    toast({ title: "Recap Generated", description: "AI has generated a brief recap for this match." });
  };

  if (authLoading || loading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!canScore && user) {
    return (
      <div className="h-screen flex items-center justify-center p-4">
        <Card className="max-w-md text-center p-8 space-y-4">
          <Activity className="mx-auto h-12 w-12 text-destructive opacity-20" />
          <h2 className="text-xl font-bold">Unauthorized</h2>
          <p className="text-muted-foreground text-sm">You do not have permission to access the scoring console. Please contact the administrator.</p>
          <Button onClick={() => router.push('/')} variant="outline" className="w-full">Return to Dashboard</Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background font-body">
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/admin">
              <Button variant="ghost" size="icon"><ArrowLeft className="h-5 w-5" /></Button>
            </Link>
            <h1 className="text-xl font-bold flex items-center gap-2">
              <Activity className="text-secondary h-5 w-5" /> Official Scoring Console
            </h1>
          </div>
          <div className="flex items-center gap-4">
            {assignedCourt && (
              <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20">
                COURT {assignedCourt} ONLY
              </Badge>
            )}
            <Badge variant="outline" className="capitalize">Scorer: {userEmail}</Badge>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {!selectedMatchId ? (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">
                {assignedCourt ? `Active Matches for Court ${assignedCourt}` : "Select Active Match to Score"}
              </h2>
            </div>
            
            <div className="grid gap-4">
              {activeMatches.map(match => {
                const t1 = state.teams.find(t => t.id === match.team1Id);
                const t2 = state.teams.find(t => t.id === match.team2Id);
                return (
                  <Card key={match.id} className="hover:border-primary transition-all cursor-pointer group" onClick={() => setSelectedMatchId(match.id)}>
                    <CardContent className="p-6 flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant={match.status === 'live' ? 'secondary' : 'outline'}>
                            {match.status === 'live' ? 'LIVE' : 'SCHEDULED'}
                          </Badge>
                          <span className="text-xs font-bold text-muted-foreground uppercase">Court {match.court} • {match.time}</span>
                        </div>
                        <div className="flex items-center gap-4 text-xl font-bold">
                          <span>{t1?.name}</span>
                          <span className="text-sm font-light text-muted-foreground">vs</span>
                          <span>{t2?.name}</span>
                        </div>
                      </div>
                      <Button variant="outline" className="group-hover:bg-primary group-hover:text-white transition-all">Start Scoring</Button>
                    </CardContent>
                  </Card>
                );
              })}
              {activeMatches.length === 0 && (
                <div className="text-center py-20 bg-muted/20 rounded-xl border-dashed border-2">
                  <Activity className="mx-auto h-12 w-12 text-muted-foreground opacity-20 mb-4" />
                  <p className="text-muted-foreground">No active matches found {assignedCourt ? `for Court ${assignedCourt}` : ""}.</p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="max-w-3xl mx-auto">
            <Button variant="ghost" onClick={() => setSelectedMatchId(null)} className="mb-6"><ChevronLeft className="mr-2 h-4 w-4" /> Back to list</Button>
            
            {selectedMatch && (
              <div className="space-y-6">
                <Card className="border-none shadow-xl overflow-hidden bg-white">
                  <div className="bg-primary p-4 text-white flex justify-between items-center">
                    <div>
                      <h3 className="font-bold text-lg">MATCH CONSOLE</h3>
                      <p className="text-xs opacity-80 uppercase font-black">Round {selectedMatch.round} • Court {selectedMatch.court}</p>
                    </div>
                    {selectedMatch.status === 'scheduled' ? (
                      <Button variant="secondary" onClick={() => setMatchStatus(selectedMatch.id, 'live')}>
                        <Play className="mr-2 h-4 w-4" /> START MATCH
                      </Button>
                    ) : (
                      <div className="flex items-center gap-2">
                        <Badge className="bg-white text-primary animate-pulse">LIVE</Badge>
                        <Button variant="destructive" size="sm" onClick={() => handleCompleteMatch(selectedMatch.id)}>
                          <Square className="mr-2 h-3 w-3" /> END MATCH
                        </Button>
                      </div>
                    )}
                  </div>
                  <CardContent className="p-8">
                    <div className="grid grid-cols-1 gap-12">
                      <ScoringControl 
                        team={state.teams.find(t => t.id === selectedMatch.team1Id)!} 
                        score={selectedMatch.gameScores[0].team1Score}
                        onIncrement={() => handleScoreChange(selectedMatch.id, 1, 1, 0)}
                        onDecrement={() => handleScoreChange(selectedMatch.id, 1, -1, 0)}
                        color="text-primary"
                      />
                      <div className="h-px bg-border flex items-center justify-center relative">
                        <span className="bg-white px-4 text-xs font-black text-muted-foreground uppercase tracking-widest">VS</span>
                      </div>
                      <ScoringControl 
                        team={state.teams.find(t => t.id === selectedMatch.team2Id)!} 
                        score={selectedMatch.gameScores[0].team2Score}
                        onIncrement={() => handleScoreChange(selectedMatch.id, 2, 1, 0)}
                        onDecrement={() => handleScoreChange(selectedMatch.id, 2, -1, 0)}
                        color="text-secondary"
                      />
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

function ScoringControl({ team, score, onIncrement, onDecrement, color }: { 
  team: any, score: number, onIncrement: () => void, onDecrement: () => void, color: string 
}) {
  return (
    <div className="flex flex-col items-center gap-6">
      <div className="text-center">
        <h4 className="text-2xl font-black">{team?.name}</h4>
        <p className="text-sm text-muted-foreground">{team?.player1} & {team?.player2}</p>
      </div>
      <div className="flex items-center gap-8">
        <Button variant="outline" size="icon" className="h-16 w-16 rounded-full border-2" onClick={onDecrement}>
          <ChevronLeft className="h-8 w-8" />
        </Button>
        <span className={`text-8xl font-black tabular-nums w-40 text-center ${color}`}>
          {score}
        </span>
        <Button variant="outline" size="icon" className="h-16 w-16 rounded-full border-2 bg-muted/20" onClick={onIncrement}>
          <ChevronRight className="h-8 w-8" />
        </Button>
      </div>
    </div>
  );
}