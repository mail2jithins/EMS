"use client";

import React, { useState, useEffect } from 'react';
import { useTournament } from "@/lib/tournament-context";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup, SelectLabel } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Trophy, Users, Calendar, Plus, Trash2, ArrowLeft, PlayCircle, LogOut, Loader2, Settings as SettingsIcon, Save, Sparkles, Table as TableIcon, Layers, RefreshCcw, Edit3, Check, X, Database, AlertTriangle, FileDown, FileJson } from "lucide-react";
import Link from 'next/link';
import { useToast } from "@/hooks/use-toast";
import { GroupLetter, MatchStage, Team, Match, GameScore } from '@/lib/types';
import { useAuth, useUser } from '@/firebase';
import { signOut } from 'firebase/auth';
import { useRouter } from 'next/navigation';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { sortTeams } from '@/lib/utils';

export default function AdminPage() {
  const { 
    state, 
    loading, 
    userRole, 
    addTeam, 
    createMatch, 
    generateRoundRobinMatches, 
    generateKnockoutPQMatches, 
    generateKnockoutQuarterMatches,
    generateKnockoutSemiMatches,
    generateFinalsMatches,
    deleteTeam, 
    deleteMatch, 
    updateSettings, 
    resetTournament, 
    updateTeam, 
    updateFullMatchScores, 
    fixKnockoutIdentifiers 
  } = useTournament();
  
  const { user, loading: authLoading } = useUser();
  const auth = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("teams");

  const [resetPassword, setResetPassword] = useState("");
  const [isResetDialogOpen, setIsResetDialogOpen] = useState(false);
  const [isResetting, setIsResetting] = useState(false);

  const [repairMatchId, setRepairMatchId] = useState("");
  const [repairScores, setRepairScores] = useState<GameScore[]>([
    { team1Score: 0, team2Score: 0 },
    { team1Score: 0, team2Score: 0 },
    { team1Score: 0, team2Score: 0 }
  ]);

  const [editingTeamId, setEditingTeamId] = useState<string | null>(null);
  const [editStats, setEditStats] = useState({ wins: 0, losses: 0, points: 0 });
  
  const [editingTeamDetailsId, setEditingTeamDetailsId] = useState<string | null>(null);
  const [editDetails, setEditDetails] = useState({ name: '', player1: '', player2: '' });

  const [editingMatchId, setEditingMatchId] = useState<string | null>(null);
  const [editMatchScores, setEditMatchScores] = useState<GameScore[]>([]);
  const [isMatchEditorOpen, setIsMatchEditorOpen] = useState(false);

  const [isOverrideDialogOpen, setIsOverrideDialogOpen] = useState(false);
  const [overridePassword, setOverridePassword] = useState("");
  const [isSavingData, setIsSavingData] = useState(false);
  const [isFixingData, setIsFixingData] = useState(false);
  const [saveMode, setSaveMode] = useState<'stats' | 'details' | 'match' | 'repair'>('stats');

  const isAdmin = userRole === 'admin';

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login');
    } else if (!authLoading && user && userRole !== null && userRole !== 'admin') {
      router.push('/scoring');
    }
  }, [user, authLoading, userRole, router]);

  const [newTeam, setNewTeam] = useState<{ name: string; player1: string; player2: string; group: GroupLetter }>({ 
    name: '', player1: '', player2: '', group: 'A' 
  });

  const [newMatch, setNewMatch] = useState({
    team1Id: '',
    team2Id: '',
    stage: 'round-robin' as MatchStage,
    roundName: 'PQ1',
    court: '1',
    group: 'A' as GroupLetter,
    numGames: 1
  });

  const [maxTeamsInput, setMaxTeamsInput] = useState(state.settings.maxTeams.toString());

  useEffect(() => {
    setMaxTeamsInput(state.settings.maxTeams.toString());
  }, [state.settings.maxTeams]);

  if (authLoading || loading || (user && userRole === null)) {
    return (
      <div className="h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  const handleAddTeam = () => {
    const teamsInGroup = state.teams.filter(t => t.group === newTeam.group).length;
    if (teamsInGroup >= 10) {
      toast({ variant: "destructive", title: "Group Limit Reached", description: "Groups are limited to 10 teams each." });
      return;
    }
    if (!newTeam.name || !newTeam.player1 || !newTeam.player2) {
      toast({ title: "Missing Information" });
      return;
    }
    addTeam(newTeam);
    setNewTeam({ ...newTeam, name: '', player1: '', player2: '' });
  };

  const handleCreateMatch = () => {
    if (!newMatch.team1Id || !newMatch.team2Id || newMatch.team1Id === newMatch.team2Id) {
      toast({ variant: "destructive", title: "Invalid Matchup", description: "Please select two different teams." });
      return;
    }
    
    const matchData: any = {
      team1Id: newMatch.team1Id,
      team2Id: newMatch.team2Id,
      stage: newMatch.stage,
      status: 'scheduled' as const,
      court: newMatch.court || '1',
    };

    if (newMatch.stage === 'knockout') {
      matchData.roundName = newMatch.roundName;
    } else {
      matchData.group = newMatch.group;
    }

    createMatch(matchData, newMatch.numGames);
    toast({ title: "Match Scheduled" });
    setNewMatch({ ...newMatch, team1Id: '', team2Id: '' });
  };

  const handleSaveSettings = () => {
    const num = parseInt(maxTeamsInput);
    if (isNaN(num) || num < 4) return;
    updateSettings({ maxTeams: num });
    toast({ title: "Settings Saved" });
  };

  const handleFixKnockoutData = async () => {
    setIsFixingData(true);
    try {
      await fixKnockoutIdentifiers();
      toast({ title: "Data Repaired", description: "Knockout identifiers have been assigned to older matches." });
    } catch (e) {
      toast({ variant: "destructive", title: "Repair Failed" });
    } finally {
      setIsFixingData(false);
    }
  };

  const handleResetTournament = async () => {
    if (resetPassword !== "emssc26") {
      toast({ variant: "destructive", title: "Incorrect Password" });
      return;
    }
    setIsResetting(true);
    try {
      await resetTournament();
      toast({ title: "Tournament Reset" });
      setIsResetDialogOpen(false);
      setResetPassword("");
    } catch (error) {
      toast({ variant: "destructive", title: "Reset Failed" });
    } finally {
      setIsResetting(false);
    }
  };

  const startEditingTeam = (team: any) => {
    setEditingTeamId(team.id);
    setEditStats({ wins: team.wins, losses: team.losses, points: team.points });
  };

  const startEditingTeamDetails = (team: Team) => {
    setEditingTeamDetailsId(team.id);
    setEditDetails({ name: team.name, player1: team.player1, player2: team.player2 });
  };

  const startEditingMatch = (match: Match) => {
    setEditingMatchId(match.id);
    setEditMatchScores(match.gameScores.map(g => ({ 
      team1Score: Number(g.team1Score || 0), 
      team2Score: Number(g.team2Score || 0) 
    })));
    setIsMatchEditorOpen(true);
  };

  const handleConfirmSave = async () => {
    if (overridePassword !== "emssc26") {
      toast({ variant: "destructive", title: "Incorrect Password" });
      return;
    }

    setIsSavingData(true);
    try {
      if (saveMode === 'stats' && editingTeamId) {
        const teamInState = state.teams.find(t => t.id === editingTeamId) as any;
        const adjWins = Number(editStats.wins) - (teamInState?._matchWins || 0);
        const adjLosses = Number(editStats.losses) - (teamInState?._matchLosses || 0);
        const adjPoints = Number(editStats.points) - (teamInState?._matchPoints || 0);

        await updateTeam(editingTeamId, { 
          wins: adjWins, 
          losses: adjLosses, 
          points: adjPoints 
        });
        toast({ title: "Standings Updated" });
        setEditingTeamId(null);
      } else if (saveMode === 'details' && editingTeamDetailsId) {
        await updateTeam(editingTeamDetailsId, editDetails);
        toast({ title: "Team Updated" });
        setEditingTeamDetailsId(null);
      } else if (saveMode === 'match' && editingMatchId) {
        await updateFullMatchScores(editingMatchId, editMatchScores);
        toast({ title: "Match Updated", description: "Scores successfully saved." });
        setEditingMatchId(null);
        setIsMatchEditorOpen(false);
      } else if (saveMode === 'repair' && repairMatchId) {
        await updateFullMatchScores(repairMatchId, repairScores.slice(0, 3));
        toast({ title: "Repair Success", description: `Match ${repairMatchId} updated.` });
        setRepairMatchId("");
      }
      setIsOverrideDialogOpen(false);
      setOverridePassword("");
    } catch (error) {
      toast({ variant: "destructive", title: "Update Failed", description: "Database rejected the request." });
    } finally {
      setIsSavingData(false);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    router.push('/');
  };

  const handleGenerateRoundRobin = () => {
    generateRoundRobinMatches();
    toast({ title: "Round Robin Schedule Generated" });
  };

  const handleGenerateKnockoutPQ = () => {
    generateKnockoutPQMatches();
    toast({ title: "Pre-Quarter Schedule Generated" });
  };

  const handleGenerateKnockoutQuarter = () => {
    generateKnockoutQuarterMatches();
    toast({ title: "Quarter-Final Schedule Generated" });
  };

  const handleGenerateKnockoutSemi = () => {
    generateKnockoutSemiMatches();
    toast({ title: "Semi-Final Schedule Generated" });
  };

  const handleGenerateFinals = () => {
    generateFinalsMatches();
    toast({ title: "Finals Schedule Generated" });
  };

  const exportToCSV = (type: 'teams' | 'matches') => {
    let headers: string[] = [];
    let rows: any[] = [];
    let filename = "";

    const escapeCSV = (field: any) => {
      const stringified = String(field || '');
      if (stringified.includes(',') || stringified.includes('"') || stringified.includes('\n')) {
        return `"${stringified.replace(/"/g, '""')}"`;
      }
      return stringified;
    };

    if (type === 'teams') {
      headers = ['ID', 'Name', 'Player 1', 'Player 2', 'Group', 'Wins', 'Losses', 'Points'];
      rows = state.teams.map(t => [
        t.id, 
        escapeCSV(t.name), 
        escapeCSV(t.player1), 
        escapeCSV(t.player2), 
        t.group, 
        t.wins, 
        t.losses, 
        t.points
      ]);
      filename = `ems_teams_${new Date().toISOString().split('T')[0]}.csv`;
    } else {
      headers = ['ID', 'Stage', 'Round/Group', 'Team 1', 'Team 2', 'Court', 'Status', 'Winner', 'Game 1', 'Game 2', 'Game 3', 'Summary Score'];
      rows = state.matches.map(m => {
        const team1 = state.teams.find(t => t.id === m.team1Id);
        const team2 = state.teams.find(t => t.id === m.team2Id);
        
        const t1Name = team1?.name || 'TBD';
        const t2Name = team2?.name || 'TBD';
        
        const setsWon1 = m.gameScores.filter(g => Number(g.team1Score || 0) > Number(g.team2Score || 0)).length;
        const setsWon2 = m.gameScores.filter(g => Number(g.team2Score || 0) > Number(g.team1Score || 0)).length;
        
        let winner = 'N/A';
        if (m.status === 'completed') {
          if (setsWon1 > setsWon2) winner = t1Name;
          else if (setsWon2 > setsWon1) winner = t2Name;
          else winner = 'Draw/Tie';
        }

        const g1 = m.gameScores[0] ? `${m.gameScores[0].team1Score}-${m.gameScores[0].team2Score}` : '-';
        const g2 = m.gameScores[1] ? `${m.gameScores[1].team1Score}-${m.gameScores[1].team2Score}` : '-';
        const g3 = m.gameScores[2] ? `${m.gameScores[2].team1Score}-${m.gameScores[2].team2Score}` : '-';
        
        const summaryScore = m.gameScores.map(g => `${g.team1Score}-${g.team2Score}`).join(' | ');

        return [
          m.id, 
          m.stage, 
          m.stage === 'knockout' ? m.roundName : m.group, 
          escapeCSV(t1Name), 
          escapeCSV(t2Name), 
          m.court, 
          m.status, 
          escapeCSV(winner),
          g1,
          g2,
          g3,
          escapeCSV(summaryScore)
        ];
      });
      filename = `ems_matches_${new Date().toISOString().split('T')[0]}.csv`;
    }

    const csvContent = [headers, ...rows].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportToJSON = () => {
    const data = JSON.stringify(state, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `ems_badminton_full_export_${new Date().getTime()}.json`);
    link.click();
  };

  const knockoutGroups = [
    { label: 'Round of 16', prefix: 'PQ', codes: ['PQ1', 'PQ2', 'PQ3', 'PQ4', 'PQ5', 'PQ6', 'PQ7', 'PQ8'] },
    { label: 'Quarter', prefix: 'Q', codes: ['Q1', 'Q2', 'Q3', 'Q4'] },
    { label: 'Semi', prefix: 'S', codes: ['S1', 'S2'] },
    { label: 'Placement', prefix: '', codes: ['TP', 'F'] }
  ];

  return (
    <div className="min-h-screen bg-background font-body pb-20">
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon"><ArrowLeft className="h-5 w-5" /></Button>
            </Link>
            <h1 className="text-xl font-bold flex items-center gap-2">
              <Trophy className="text-primary h-5 w-5" /> Admin Console
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/scoring">
              <Button variant="secondary" className="gap-2 font-bold">
                <PlayCircle className="h-4 w-4" /> Scoring Console
              </Button>
            </Link>
            <Button variant="ghost" size="icon" onClick={handleLogout}><LogOut className="h-5 w-5" /></Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid grid-cols-4 max-w-2xl bg-white border">
            <TabsTrigger value="teams" className="gap-2"><Users className="h-4 w-4" /> Teams</TabsTrigger>
            <TabsTrigger value="matches" className="gap-2"><Calendar className="h-4 w-4" /> Schedule</TabsTrigger>
            <TabsTrigger value="standings" className="gap-2"><TableIcon className="h-4 w-4" /> Standings</TabsTrigger>
            <TabsTrigger value="settings" className="gap-2"><SettingsIcon className="h-4 w-4" /> Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="teams" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <Card className="shadow-sm bg-white">
                <CardHeader><CardTitle>Register Team</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Group</Label>
                    <Select value={newTeam.group} onValueChange={v => setNewTeam({...newTeam, group: v as GroupLetter})}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {['A', 'B', 'C', 'D'].map(g => (<SelectItem key={g} value={g}>Group {g}</SelectItem>))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Input placeholder="Team Name" value={newTeam.name} onChange={e => setNewTeam({...newTeam, name: e.target.value})} />
                  <Input placeholder="Player 1" value={newTeam.player1} onChange={e => setNewTeam({...newTeam, player1: e.target.value})} />
                  <Input placeholder="Player 2" value={newTeam.player2} onChange={e => setNewTeam({...newTeam, player2: e.target.value})} />
                  <Button className="w-full gap-2 font-bold" onClick={handleAddTeam}><Plus className="h-4 w-4" /> Add Team</Button>
                </CardContent>
              </Card>

              <Card className="lg:col-span-2 shadow-sm bg-white">
                <CardHeader><CardTitle>Registered Teams</CardTitle></CardHeader>
                <CardContent>
                   <Tabs defaultValue="A">
                     <TabsList className="mb-4">
                       {['A', 'B', 'C', 'D'].map(g => {
                         const count = state.teams.filter(t => t.group === g).length;
                         return (
                           <TabsTrigger key={g} value={g}>
                             Group {g} <span className="ml-1 opacity-50 text-[10px]">({count}/10)</span>
                           </TabsTrigger>
                         );
                       })}
                     </TabsList>
                     {['A', 'B', 'C', 'D'].map(g => (
                       <TabsContent key={g} value={g}>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                           {state.teams.filter(t => t.group === g).map(team => (
                             <div key={team.id} className="p-3 border rounded-lg flex items-center justify-between group bg-white">
                               <div className="flex-1 mr-4">
                                 {editingTeamDetailsId === team.id ? (
                                   <div className="space-y-2">
                                     <Input className="h-8 text-xs" value={editDetails.name} onChange={e => setEditDetails({...editDetails, name: e.target.value})} />
                                     <div className="flex gap-2">
                                       <Input className="h-8 text-[10px]" value={editDetails.player1} onChange={e => setEditDetails({...editDetails, player1: e.target.value})} />
                                       <Input className="h-8 text-[10px]" value={editDetails.player2} onChange={e => setEditDetails({...editDetails, player2: e.target.value})} />
                                     </div>
                                   </div>
                                 ) : (
                                   <>
                                     <p className="font-bold text-sm">{team.name}</p>
                                     <p className="text-[10px] text-muted-foreground">{team.player1} & {team.player2}</p>
                                   </>
                                 )}
                               </div>
                               <div className="flex items-center gap-1">
                                 {editingTeamDetailsId === team.id ? (
                                   <>
                                     <Button variant="ghost" size="icon" className="h-8 w-8 text-green-600" onClick={() => { setSaveMode('details'); setIsOverrideDialogOpen(true); }}><Check className="h-4 w-4" /></Button>
                                     <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setEditingTeamDetailsId(null)}><X className="h-4 w-4" /></Button>
                                   </>
                                 ) : (
                                   <>
                                     <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 h-8 w-8" onClick={() => startEditingTeamDetails(team)}><Edit3 className="h-4 w-4" /></Button>
                                     <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 h-8 w-8 text-destructive" onClick={() => deleteTeam(team.id)}><Trash2 className="h-4 w-4" /></Button>
                                   </>
                                 )}
                               </div>
                             </div>
                           ))}
                         </div>
                       </TabsContent>
                     ))}
                   </Tabs>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="matches" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
               <div className="space-y-6">
                 <Card className="shadow-sm bg-white">
                  <CardHeader><CardTitle>Manual Schedule</CardTitle></CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label>Match Type</Label>
                      <Select value={newMatch.stage} onValueChange={v => setNewMatch({...newMatch, stage: v as MatchStage})}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="round-robin">Round Robin</SelectItem>
                          <SelectItem value="knockout">Knockout stage</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    {newMatch.stage === 'round-robin' ? (
                      <div className="space-y-2">
                        <Label>Group</Label>
                        <Select value={newMatch.group} onValueChange={v => setNewMatch({...newMatch, group: v as GroupLetter})}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {['A', 'B', 'C', 'D'].map(g => (<SelectItem key={g} value={g}>Group {g}</SelectItem>))}
                          </SelectContent>
                        </Select>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <Label>Knockout Round Identifier</Label>
                        <Select value={newMatch.roundName} onValueChange={v => setNewMatch({...newMatch, roundName: v})}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {knockoutGroups.map(group => (
                              <SelectGroup key={group.label}>
                                <SelectLabel>{group.label}</SelectLabel>
                                {group.codes.map(code => (<SelectItem key={code} value={code}>{code}</SelectItem>))}
                              </SelectGroup>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                    <div className="space-y-2">
                      <Label>Team 1</Label>
                      <Select value={newMatch.team1Id} onValueChange={v => setNewMatch({...newMatch, team1Id: v})}>
                        <SelectTrigger><SelectValue placeholder="Select Team 1" /></SelectTrigger>
                        <SelectContent>
                          {state.teams.filter(t => newMatch.stage === 'knockout' || t.group === newMatch.group).map(t => (
                            <SelectItem key={t.id} value={t.id}>{t.name} {t.group && `(Grp ${t.group})`}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Team 2</Label>
                      <Select value={newMatch.team2Id} onValueChange={v => setNewMatch({...newMatch, team2Id: v})}>
                        <SelectTrigger><SelectValue placeholder="Select Team 2" /></SelectTrigger>
                        <SelectContent>
                          {state.teams.filter(t => newMatch.stage === 'knockout' || t.group === newMatch.group).map(t => (
                            <SelectItem key={t.id} value={t.id}>{t.name} {t.group && `(Grp ${t.group})`}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Court</Label>
                        <Input value={newMatch.court} onChange={e => setNewMatch({...newMatch, court: e.target.value})} />
                      </div>
                      <div className="space-y-2">
                        <Label>Number of Games</Label>
                        <Input type="number" min="1" max="5" value={newMatch.numGames} onChange={e => setNewMatch({...newMatch, numGames: parseInt(e.target.value) || 1})} />
                      </div>
                    </div>
                    <Button className="w-full gap-2 font-bold" onClick={handleCreateMatch}><Plus className="h-4 w-4" /> Schedule Match</Button>
                  </CardContent>
                </Card>
                <Card className="shadow-sm bg-primary/5 border-primary/20">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Sparkles className="h-5 w-5 text-primary" /> Auto-Scheduler</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button className="w-full gap-2 font-bold" variant="outline" onClick={handleGenerateRoundRobin}>Generate Round Robin</Button>
                    <Button className="w-full gap-2 font-bold" variant="outline" onClick={handleGenerateKnockoutPQ}>Generate Pre-Quarter (KO)</Button>
                    <Button className="w-full gap-2 font-bold" variant="outline" onClick={handleGenerateKnockoutQuarter}>Generate Quarter Finals</Button>
                    <Button className="w-full gap-2 font-bold" variant="outline" onClick={handleGenerateKnockoutSemi}>Generate Semi Finals</Button>
                    <Button className="w-full gap-2 font-bold" variant="outline" onClick={handleGenerateFinals}>Generate Finals (Final & 3rd Place)</Button>
                  </CardContent>
                </Card>
               </div>

              <Card className="lg:col-span-2 shadow-sm bg-white">
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle>Match Schedule</CardTitle>
                  <Badge variant="outline">{state.matches.length} Total Matches</Badge>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="round-robin">
                    <TabsList className="mb-4">
                      <TabsTrigger value="round-robin">Round Robin</TabsTrigger>
                      <TabsTrigger value="knockout">Knockout Stage</TabsTrigger>
                    </TabsList>
                    <TabsContent value="round-robin" className="space-y-4">
                      {state.matches.filter(m => m.stage === 'round-robin').map(match => (
                        <div key={match.id} className="p-4 border rounded-xl flex items-center justify-between group bg-white">
                          <div>
                            <div className="flex items-center gap-2 mb-2">
                              <Badge variant="outline">Group {match.group}</Badge>
                              <Badge variant="outline">Court {match.court}</Badge>
                              <Badge variant={match.status === 'completed' ? 'default' : 'secondary'}>{match.status}</Badge>
                            </div>
                            <div className="font-bold">
                              {state.teams.find(t => t.id === match.team1Id)?.name} vs {state.teams.find(t => t.id === match.team2Id)?.name}
                            </div>
                            <div className="text-[10px] text-muted-foreground font-mono mt-1">ID: {match.id}</div>
                          </div>
                          <Button variant="ghost" className="text-destructive opacity-0 group-hover:opacity-100" onClick={() => deleteMatch(match.id)}><Trash2 className="h-4 w-4" /></Button>
                        </div>
                      ))}
                    </TabsContent>
                    <TabsContent value="knockout" className="space-y-4">
                      {state.matches.filter(m => m.stage === 'knockout').map(match => (
                        <div key={match.id} className="p-4 border rounded-xl flex items-center justify-between group bg-white">
                          <div>
                            <div className="flex items-center gap-2 mb-2">
                              <Badge variant="secondary">{match.roundName}</Badge>
                              <Badge variant="outline">Court {match.court}</Badge>
                              <Badge variant={match.status === 'completed' ? 'default' : 'secondary'}>{match.status}</Badge>
                            </div>
                            <div className="font-bold">
                              {state.teams.find(t => t.id === match.team1Id)?.name || 'TBD'} vs {state.teams.find(t => t.id === match.team2Id)?.name || 'TBD'}
                            </div>
                            <div className="text-[10px] text-muted-foreground font-mono mt-1">ID: {match.id}</div>
                          </div>
                          <Button variant="ghost" className="text-destructive opacity-0 group-hover:opacity-100" onClick={() => deleteMatch(match.id)}><Trash2 className="h-4 w-4" /></Button>
                        </div>
                      ))}
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="standings" className="space-y-6">
            <div className="grid grid-cols-1 gap-8">
              <Card className="shadow-sm bg-white">
                <CardHeader><CardTitle className="flex items-center gap-2"><TableIcon className="h-5 w-5 text-primary" /> Round Robin Summary</CardTitle></CardHeader>
                <CardContent>
                  <Tabs defaultValue="A">
                    <TabsList className="mb-4">
                      {['A', 'B', 'C', 'D'].map(g => (<TabsTrigger key={g} value={g}>Group {g}</TabsTrigger>))}
                    </TabsList>
                    {(['A', 'B', 'C', 'D'] as GroupLetter[]).map(group => {
                      const groupTeams = state.teams.filter(t => t.group === group);
                      const sortedTeams = sortTeams(groupTeams, state.matches);
                      return (
                        <TabsContent key={group} value={group}>
                          <div className="rounded-md border">
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead className="w-12">Rank</TableHead>
                                  <TableHead>Team</TableHead>
                                  <TableHead className="text-center">Wins</TableHead>
                                  <TableHead className="text-center">Losses</TableHead>
                                  <TableHead className="text-center">Points</TableHead>
                                  <TableHead className="text-right">Action</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {sortedTeams.map((team, idx) => (
                                  <TableRow key={team.id} className={idx < 4 ? "bg-secondary/5" : ""}>
                                    <TableCell className="font-bold">#{idx + 1}</TableCell>
                                    <TableCell>
                                      <div className="font-bold text-sm">{team.name}</div>
                                      <div className="text-[10px] text-muted-foreground">{team.player1} & {team.player2}</div>
                                    </TableCell>
                                    <TableCell className="text-center">
                                      {editingTeamId === team.id ? (
                                        <Input type="number" className="w-16 h-8 mx-auto" value={editStats.wins} onChange={e => setEditStats({...editStats, wins: parseInt(e.target.value) || 0})} />
                                      ) : team.wins}
                                    </TableCell>
                                    <TableCell className="text-center">
                                      {editingTeamId === team.id ? (
                                        <Input type="number" className="w-16 h-8 mx-auto" value={editStats.losses} onChange={e => setEditStats({...editStats, losses: parseInt(e.target.value) || 0})} />
                                      ) : team.losses}
                                    </TableCell>
                                    <TableCell className="text-center font-bold text-primary">
                                      {editingTeamId === team.id ? (
                                        <Input type="number" className="w-20 h-8 mx-auto" value={editStats.points} onChange={e => setEditStats({...editStats, points: parseInt(e.target.value) || 0})} />
                                      ) : team.points}
                                    </TableCell>
                                    <TableCell className="text-right">
                                      {editingTeamId === team.id ? (
                                        <div className="flex justify-end gap-1">
                                          <Button variant="ghost" size="icon" className="h-8 w-8 text-green-600" onClick={() => { setSaveMode('stats'); setIsOverrideDialogOpen(true); }}><Check className="h-4 w-4" /></Button>
                                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setEditingTeamId(null)}><X className="h-4 w-4" /></Button>
                                        </div>
                                      ) : (
                                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => startEditingTeam(team)}><Edit3 className="h-4 w-4" /></Button>
                                      )}
                                    </TableCell>
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </div>
                        </TabsContent>
                      );
                    })}
                  </Tabs>
                </CardContent>
              </Card>

              <Card className="shadow-sm bg-white">
                <CardHeader><CardTitle className="flex items-center gap-2"><Layers className="h-5 w-5 text-secondary" /> Knockout Stage Summary</CardTitle></CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {knockoutGroups.map(roundGroup => {
                      const roundMatches = state.matches.filter(m => 
                        m.stage === 'knockout' && m.roundName && roundGroup.codes.includes(m.roundName)
                      );
                      if (roundMatches.length === 0) return null;
                      return (
                        <div key={roundGroup.label} className="space-y-3">
                          <h3 className="text-sm font-black text-muted-foreground uppercase tracking-widest border-b pb-1">{roundGroup.label}</h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {roundMatches.map(match => {
                              const t1 = state.teams.find(t => t.id === match.team1Id);
                              const t2 = state.teams.find(t => t.id === match.team2Id);
                              const completed = match.status === 'completed';
                              const setsWon1 = match.gameScores.filter(g => Number(g.team1Score || 0) > Number(g.team2Score || 0)).length;
                              const setsWon2 = match.gameScores.filter(g => Number(g.team2Score || 0) > Number(g.team1Score || 0)).length;
                              const isMultiGame = match.gameScores.length > 1;
                              const score1 = isMultiGame ? setsWon1 : match.gameScores.reduce((sum, g) => sum + (Number(g.team1Score) || 0), 0);
                              const score2 = isMultiGame ? setsWon2 : match.gameScores.reduce((sum, g) => sum + (Number(g.team2Score) || 0), 0);
                              return (
                                <div key={match.id} className={`p-4 border rounded-xl bg-muted/10 relative group ${completed ? 'opacity-80' : 'ring-1 ring-secondary/30'}`}>
                                  <div className="flex justify-between items-center mb-2">
                                    <div className="flex flex-col gap-1">
                                      <Badge variant="outline" className="text-[8px] w-fit">{match.roundName} • Court {match.court}</Badge>
                                      <span className="text-[7px] text-muted-foreground font-mono">ID: {match.id}</span>
                                    </div>
                                    <Button variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100" onClick={() => startEditingMatch(match)}><Edit3 className="h-3 w-3" /></Button>
                                  </div>
                                  <div className="space-y-2">
                                    <div className={`flex justify-between items-center ${completed && setsWon1 > setsWon2 ? 'font-black text-primary' : ''}`}>
                                      <span className="truncate text-sm">{t1?.name || 'TBD'}</span>
                                      <span className="text-lg">{score1}</span>
                                    </div>
                                    <div className={`flex justify-between items-center ${completed && setsWon2 > setsWon1 ? 'font-black text-primary' : ''}`}>
                                      <span className="truncate text-sm">{t2?.name || 'TBD'}</span>
                                      <span className="text-lg">{score2}</span>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card className="shadow-sm bg-white">
                <CardHeader><CardTitle>Tournament Settings</CardTitle></CardHeader>
                <CardContent className="space-y-8">
                  <div className="flex gap-4 items-end">
                    <div className="space-y-2">
                      <Label>Total Team Capacity</Label>
                      <Input type="number" value={maxTeamsInput} onChange={e => setMaxTeamsInput(e.target.value)} />
                    </div>
                    <Button onClick={handleSaveSettings} className="gap-2"><Save className="h-4 w-4" /> Save Capacity</Button>
                  </div>
                  <div className="pt-6 border-t">
                    <h3 className="text-sm font-bold mb-4">Data Repair</h3>
                    <div className="flex flex-col gap-3">
                      <Button variant="outline" onClick={handleFixKnockoutData} disabled={isFixingData} className="gap-2 h-12 justify-start">
                        {isFixingData ? <Loader2 className="animate-spin h-4 w-4" /> : <Database className="h-4 w-4" />}
                        Fix Knockout Identifiers
                      </Button>
                    </div>
                  </div>
                  <div className="pt-6 border-t">
                    <h3 className="text-sm font-bold mb-4 text-destructive font-black uppercase tracking-widest">Danger Zone</h3>
                    <Dialog open={isResetDialogOpen} onOpenChange={setIsResetDialogOpen}>
                      <DialogTrigger asChild><Button variant="destructive" className="gap-2 w-full"><RefreshCcw className="h-4 w-4" /> Reset All Data</Button></DialogTrigger>
                      <DialogContent>
                        <DialogHeader><DialogTitle>Confirm Reset</DialogTitle></DialogHeader>
                        <div className="py-4 space-y-4">
                          <Label>Admin Password</Label>
                          <Input type="password" value={resetPassword} onChange={(e) => setResetPassword(e.target.value)} />
                        </div>
                        <DialogFooter>
                          <Button variant="ghost" onClick={() => setIsResetDialogOpen(false)}>Cancel</Button>
                          <Button variant="destructive" onClick={handleResetTournament} disabled={isResetting || !resetPassword}>Confirm Reset</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-sm bg-white">
                <CardHeader><CardTitle className="flex items-center gap-2"><FileDown className="h-5 w-5 text-secondary" /> Reports & Extracts</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground mb-4">Export tournament data for offline use or backup.</p>
                  <div className="grid grid-cols-1 gap-3">
                    <Button variant="outline" className="justify-start gap-2 h-12" onClick={() => exportToCSV('teams')}>
                      <FileDown className="h-4 w-4" /> Export Team List (CSV)
                    </Button>
                    <Button variant="outline" className="justify-start gap-2 h-12" onClick={() => exportToCSV('matches')}>
                      <FileDown className="h-4 w-4" /> Export Match Schedule (CSV)
                    </Button>
                    <Button variant="outline" className="justify-start gap-2 h-12" onClick={() => exportToJSON()}>
                      <FileJson className="h-4 w-4" /> Full Tournament Export (JSON)
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-sm bg-white border-primary/20 md:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2"><AlertTriangle className="h-5 w-5 text-primary" /> Direct Match Overrider</CardTitle>
                  <CardDescription>Use this to directly fix scores if the visual editor is failing. Find the Match ID in the Schedule or Standings tab.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Target Match ID</Label>
                    <Input placeholder="Enter Match ID (e.g. 1a2b3c...)" value={repairMatchId} onChange={e => setRepairMatchId(e.target.value)} />
                  </div>
                  
                  <div className="space-y-4 pt-2">
                    {[0, 1, 2].map((idx) => (
                      <div key={idx} className="p-3 border rounded-lg bg-muted/20">
                        <Label className="text-xs font-bold mb-2 block uppercase">Game {idx + 1}</Label>
                        <div className="grid grid-cols-2 gap-4">
                          <Input type="number" placeholder="Team 1" value={repairScores[idx].team1Score} onChange={e => {
                            const ns = [...repairScores];
                            ns[idx] = { ...ns[idx], team1Score: parseInt(e.target.value) || 0 };
                            setRepairScores(ns);
                          }} />
                          <Input type="number" placeholder="Team 2" value={repairScores[idx].team2Score} onChange={e => {
                            const ns = [...repairScores];
                            ns[idx] = { ...ns[idx], team2Score: parseInt(e.target.value) || 0 };
                            setRepairScores(ns);
                          }} />
                        </div>
                      </div>
                    ))}
                  </div>

                  <Button className="w-full h-12 font-black uppercase tracking-widest gap-2" onClick={() => { setSaveMode('repair'); setIsOverrideDialogOpen(true); }}>
                    Force Overwrite Database
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        <Dialog open={isOverrideDialogOpen} onOpenChange={setIsOverrideDialogOpen}>
          <DialogContent>
            <DialogHeader><DialogTitle>Authorize Changes</DialogTitle></DialogHeader>
            <div className="py-4">
              <Label>Password</Label>
              <Input 
                type="password" 
                value={overridePassword} 
                onChange={e => setOverridePassword(e.target.value)} 
                placeholder="Enter password" 
                onKeyDown={(e) => { if (e.key === 'Enter') handleConfirmSave(); }}
              />
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setIsOverrideDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleConfirmSave} disabled={isSavingData}>{isSavingData ? <Loader2 className="animate-spin h-4 w-4" /> : "Confirm Update"}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog open={isMatchEditorOpen} onOpenChange={(open) => {
          if (!open && !isOverrideDialogOpen) {
            setIsMatchEditorOpen(false);
            setEditingMatchId(null);
          }
        }}>
          <DialogContent className="max-w-md">
            <DialogHeader><DialogTitle>Edit Match Scores</DialogTitle></DialogHeader>
            <div className="space-y-6 py-4 max-h-[60vh] overflow-y-auto pr-2">
              {editMatchScores.map((game, idx) => (
                <div key={idx} className="space-y-3 p-4 border rounded-lg bg-muted/20">
                  <h4 className="text-xs font-black uppercase tracking-widest text-muted-foreground">Game {idx + 1}</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label className="text-[10px]">Team 1 Score</Label>
                      <Input type="number" value={game.team1Score} onChange={e => {
                        const newScores = [...editMatchScores];
                        newScores[idx] = { ...newScores[idx], team1Score: parseInt(e.target.value) || 0 };
                        setEditMatchScores(newScores);
                      }} />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-[10px]">Team 2 Score</Label>
                      <Input type="number" value={game.team2Score} onChange={e => {
                        const newScores = [...editMatchScores];
                        newScores[idx] = { ...newScores[idx], team2Score: parseInt(e.target.value) || 0 };
                        setEditMatchScores(newScores);
                      }} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => {
                setIsMatchEditorOpen(false);
                setEditingMatchId(null);
              }}>Cancel</Button>
              <Button onClick={() => { 
                setSaveMode('match'); 
                setIsOverrideDialogOpen(true); 
              }}>Save Changes</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
