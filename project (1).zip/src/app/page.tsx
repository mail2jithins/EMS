"use client";

import React, { useMemo } from 'react';
import { useTournament } from "@/lib/tournament-context";
import { LiveMatches } from "@/components/dashboard/LiveMatches";
import { UpcomingMatches } from "@/components/dashboard/UpcomingMatches";
import { Standings } from "@/components/dashboard/Standings";
import { KnockoutSummary } from "@/components/dashboard/KnockoutSummary";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, LayoutDashboard, Settings, Trophy, Users, Shield, Monitor, PlayCircle } from "lucide-react";
import Link from 'next/link';
import { Match } from '@/lib/types';

export default function Dashboard() {
  const { state, userRole } = useTournament();
  
  const completedMatches = useMemo(() => {
    return [...state.matches]
      .filter(m => m.status === 'completed')
      .sort((a, b) => {
        // Prioritize Knockout Stage results in "Recent Results"
        if (a.stage !== b.stage) {
          return a.stage === 'knockout' ? -1 : 1;
        }
        
        const getPriority = (m: Match) => {
          if (m.stage === 'round-robin') return 0;
          const code = (m.roundName || '').toUpperCase();
          if (code.startsWith('F')) return 100;
          if (code.startsWith('TP')) return 90;
          if (code.startsWith('S')) return 80;
          if (code.startsWith('Q')) return 70;
          if (code.startsWith('PQ')) return 60;
          return 50;
        };

        const pA = getPriority(a);
        const pB = getPriority(b);
        if (pA !== pB) return pB - pA;
        
        return (a.roundName || '').localeCompare(b.roundName || '', undefined, { numeric: true });
      })
      .slice(0, 10);
  }, [state.matches]);

  const hasKnockout = state.matches.some(m => m.stage === 'knockout');

  const isAdmin = userRole === 'admin';
  const isScorekeeper = userRole === 'scorekeeper';

  return (
    <div className="min-h-screen bg-background font-body">
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-primary p-1.5 rounded-lg">
              <Trophy className="text-white h-6 w-6" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-primary">EMS <span className="text-secondary">Badminton</span></h1>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-semibold text-primary border-b-2 border-primary pb-1">Dashboard</Link>
            <Link href="/tv" className="text-sm font-semibold text-muted-foreground hover:text-primary transition-colors flex items-center gap-1">
              <Monitor className="h-4 w-4" /> TV Mode
            </Link>
            {isScorekeeper && (
              <Link href="/scoring" className="text-sm font-semibold text-muted-foreground hover:text-primary transition-colors flex items-center gap-1">
                <PlayCircle className="h-4 w-4" /> Scoring Console
              </Link>
            )}
            {isAdmin && (
              <Link href="/admin" className="text-sm font-semibold text-muted-foreground hover:text-primary transition-colors flex items-center gap-1">
                <Settings className="h-4 w-4" /> Admin Console
              </Link>
            )}
          </nav>
          <Button variant="outline" className="md:hidden" size="icon">
            <LayoutDashboard className="h-5 w-5" />
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-12">
            {/* 1. Live Action */}
            <LiveMatches />
            
            {/* 2. Standings (Knockout & Round Robin) */}
            <div className="space-y-8">
              {hasKnockout && <KnockoutSummary />}
              <Standings />
            </div>

            {/* 3. Upcoming Schedule */}
            <UpcomingMatches />

            {/* 4. Recent Results */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-2">
                <Calendar className="text-primary h-5 w-5" />
                <h2 className="text-xl font-bold font-headline">Recent Results</h2>
              </div>
              <div className="grid gap-4">
                {completedMatches.length === 0 ? (
                  <p className="text-sm text-muted-foreground bg-white p-4 rounded-lg border">No matches completed yet.</p>
                ) : (
                  completedMatches.map(match => {
                    const t1 = state.teams.find(t => t.id === match.team1Id);
                    const t2 = state.teams.find(t => t.id === match.team2Id);
                    
                    const setsWon1 = match.gameScores.filter(g => Number(g.team1Score || 0) > Number(g.team2Score || 0)).length;
                    const setsWon2 = match.gameScores.filter(g => Number(g.team2Score || 0) > Number(g.team1Score || 0)).length;
                    
                    const totalPoints1 = match.gameScores.reduce((sum, g) => sum + (Number(g.team1Score) || 0), 0);
                    const totalPoints2 = match.gameScores.reduce((sum, g) => sum + (Number(g.team2Score) || 0), 0);
                    
                    const team1Won = setsWon1 > setsWon2;
                    const team2Won = setsWon2 > setsWon1;
                    
                    const isMultiGame = match.gameScores.length > 1;
                    const displayScore1 = isMultiGame ? setsWon1 : totalPoints1;
                    const displayScore2 = isMultiGame ? setsWon2 : totalPoints2;
                    
                    const gamePointsText = match.gameScores.map(g => `${g.team1Score}-${g.team2Score}`).join(', ');

                    return (
                      <Card key={match.id} className="border-none shadow-sm hover:shadow-md transition-all overflow-hidden bg-white">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-3">
                            <Badge variant="default" className="text-[10px] font-black uppercase bg-primary text-white border-none h-5 px-3">
                              {match.stage === 'knockout' ? match.roundName : `GROUP ${match.group}`}
                            </Badge>
                            <span className="text-[8px] font-black text-muted-foreground uppercase tracking-widest">FINAL RESULT</span>
                          </div>
                          <div className="flex items-center justify-between gap-4">
                            <div className={`flex-1 text-right ${team1Won ? 'font-black text-primary' : ''}`}>
                              <span className="font-bold block text-sm">{t1?.name}</span>
                              <span className="text-[10px] text-muted-foreground">{t1?.player1} & {t1?.player2}</span>
                            </div>
                            <div className="flex flex-col items-center min-w-[100px]">
                              <div className="flex items-center gap-3">
                                <span className={`text-3xl font-black ${team1Won ? 'text-primary' : 'text-muted-foreground'}`}>
                                  {displayScore1}
                                </span>
                                <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-[10px] font-black shadow-inner border border-border/50">VS</div>
                                <span className={`text-3xl font-black ${team2Won ? 'text-primary' : 'text-muted-foreground'}`}>
                                  {displayScore2}
                                </span>
                              </div>
                              <span className="text-[9px] font-black text-muted-foreground uppercase mt-1 tracking-tighter">
                                {isMultiGame ? 'Sets Won' : 'Points'}
                              </span>
                            </div>
                            <div className={`flex-1 ${team2Won ? 'font-black text-primary' : ''}`}>
                              <span className="font-bold block text-sm">{t2?.name}</span>
                              <span className="text-[10px] text-muted-foreground">{t2?.player1} & {t2?.player2}</span>
                            </div>
                          </div>
                          
                          <div className="mt-4 flex flex-col gap-3">
                            <div className="flex items-center justify-center gap-4 bg-muted/20 p-2 rounded-lg border border-border/50">
                               <span className="text-[9px] font-black text-muted-foreground uppercase">Game Breakdown</span>
                               <span className="text-xs font-mono font-bold text-primary italic">({gamePointsText})</span>
                            </div>

                            {match.recap && (
                              <div className="p-3 bg-secondary/5 border-l-4 border-secondary rounded-r-md">
                                <p className="text-[10px] italic leading-relaxed text-muted-foreground">{match.recap}</p>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })
                )}
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <Card className="bg-primary text-white border-none shadow-lg overflow-hidden relative">
              <div className="absolute top-0 right-0 p-4 opacity-10">
                <Shield className="h-24 w-24 rotate-12" />
              </div>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Users className="h-5 w-5" />
                  Tournament Info
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center bg-white/10 p-3 rounded-lg">
                  <span className="text-xs font-medium">Teams Registered</span>
                  <span className="text-lg font-bold">{state.teams.length} / {state.settings.maxTeams}</span>
                </div>
                <div className="flex justify-between items-center bg-white/10 p-3 rounded-lg">
                  <span className="text-xs font-medium">Matches Finished</span>
                  <span className="text-lg font-bold">{state.matches.filter(m => m.status === 'completed').length}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}