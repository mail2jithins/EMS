
"use client";

import React, { useState, useEffect, Suspense } from 'react';
import { useAuth, useFirestore } from '@/firebase';
import { signInWithEmailAndPassword, signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardHeader, CardTitle, CardContent, CardFooter, CardDescription } from '@/components/ui/card';
import { Trophy, LogIn, ShieldCheck, Loader2, AlertCircle, Users, ArrowLeft, QrCode } from 'lucide-react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { firebaseConfig } from '@/firebase/config';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { QRCodeSVG } from 'qrcode.react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

function LoginContent() {
  const [mounted, setMounted] = useState(false);
  const auth = useAuth();
  const db = useFirestore();
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  
  const skParam = searchParams.get('sk');
  const initialEmail = skParam && ['1', '2', '3', '4'].includes(skParam) 
    ? `scorekeeper${skParam}@test.com` 
    : '';

  const [email, setEmail] = useState(initialEmail);
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [configError, setConfigError] = useState(false);

  const isDedicatedSkLogin = !!skParam;

  useEffect(() => {
    setMounted(true);
    if (!firebaseConfig.apiKey || firebaseConfig.apiKey.includes('placeholder')) {
      setConfigError(true);
    }
  }, []);

  const handleRedirectAfterLogin = async (uid: string) => {
    try {
      const userDoc = await getDoc(doc(db, 'users', uid));
      const role = userDoc.data()?.role || 'viewer';
      
      if (role === 'admin') {
        router.push('/admin');
      } else if (role === 'scorekeeper') {
        router.push('/scoring');
      } else {
        router.push('/');
      }
    } catch (error) {
      router.push('/');
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      toast({ title: "Welcome back!", description: "Redirecting..." });
      await handleRedirectAfterLogin(userCredential.user.uid);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Login Failed",
        description: "Invalid email or password. Please try again."
      });
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      const result = await signInWithPopup(auth, new GoogleAuthProvider());
      await handleRedirectAfterLogin(result.user.uid);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Google Login Failed",
        description: error.message
      });
    }
  };

  const getQRUrl = (skNum: string) => {
    if (typeof window === 'undefined') return '';
    return `${window.location.origin}/login?sk=${skNum}`;
  };

  if (!mounted) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-muted/30 p-4 font-body gap-6">
        <Loader2 className="h-8 w-8 animate-spin text-primary opacity-20" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-muted/30 p-4 font-body gap-6">
      {configError && (
        <Alert variant="destructive" className="max-w-md bg-destructive/10 border-destructive/20 text-destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Firebase Configuration Missing</AlertTitle>
          <AlertDescription>
            The Firebase API key is missing. Please ensure your project is provisioned.
          </AlertDescription>
        </Alert>
      )}

      <div className="w-full max-w-md space-y-6">
        <Card className="border-none shadow-xl bg-white overflow-hidden">
          <div className="bg-primary h-2 w-full" />
          <CardHeader className="text-center space-y-4 pt-8">
            <div className="mx-auto bg-primary/10 w-20 h-20 rounded-full flex items-center justify-center border-4 border-white shadow-sm">
              {isDedicatedSkLogin ? <Users className="text-primary h-10 w-10" /> : <Trophy className="text-primary h-10 w-10" />}
            </div>
            <div>
              <CardTitle className="text-2xl font-black">
                {isDedicatedSkLogin ? `Official Login: SK ${skParam}` : 'Tournament Login'}
              </CardTitle>
              <CardDescription>
                {isDedicatedSkLogin ? `Enter credentials for Court ${skParam}` : 'Access scoring and administration'}
              </CardDescription>
            </div>
          </CardHeader>
          <CardContent className="px-8 pb-4">
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Input 
                  type="email" 
                  placeholder="Official Email" 
                  value={email} 
                  onChange={(e) => setEmail(e.target.value)} 
                  required 
                  disabled={configError}
                  className="h-12"
                />
              </div>
              <div className="space-y-2">
                <Input 
                  type="password" 
                  placeholder="Password" 
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)} 
                  required 
                  disabled={configError}
                  className="h-12"
                />
              </div>
              <Button type="submit" className="w-full h-12 font-bold text-lg" disabled={loading || configError}>
                {loading ? <Loader2 className="animate-spin h-5 w-5" /> : <LogIn className="mr-2 h-5 w-5" />}
                {loading ? 'Verifying...' : 'Sign In'}
              </Button>
            </form>

            {!isDedicatedSkLogin && (
              <>
                <div className="relative my-8">
                  <div className="absolute inset-0 flex items-center"><span className="w-full border-t" /></div>
                  <div className="relative flex justify-center text-xs uppercase"><span className="bg-white px-2 text-muted-foreground">Or</span></div>
                </div>
                <Button variant="outline" className="w-full h-11" onClick={handleGoogleLogin} disabled={loading || configError}>
                  Sign in with Google
                </Button>
              </>
            )}
          </CardContent>
          <CardFooter className="flex flex-col gap-4 pb-8">
            {isDedicatedSkLogin ? (
              <Button 
                variant="ghost" 
                className="text-xs text-muted-foreground flex items-center gap-1"
                onClick={() => router.push('/login')}
              >
                <ArrowLeft className="h-3 w-3" /> Use different account
              </Button>
            ) : (
              <Button variant="link" className="text-xs text-muted-foreground" onClick={() => router.push('/')}>
                Back to Public Dashboard
              </Button>
            )}
          </CardFooter>
        </Card>

        {!isDedicatedSkLogin && (
          <Card className="border-dashed border-2 bg-transparent">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-bold flex items-center gap-2">
                <QrCode className="h-4 w-4" /> Official Quick Access
              </CardTitle>
              <CardDescription className="text-xs">Scan to open Court-specific login</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-2">
              {['1', '2', '3', '4'].map((sk) => (
                <Dialog key={sk}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="justify-start gap-2 h-9 text-xs">
                      <QrCode className="h-3 w-3" /> Court {sk}
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-xs text-center">
                    <DialogHeader>
                      <DialogTitle>Court {sk} Login</DialogTitle>
                    </DialogHeader>
                    <div className="p-4 bg-white rounded-lg flex justify-center">
                      <QRCodeSVG value={getQRUrl(sk)} size={200} />
                    </div>
                    <p className="text-[10px] text-muted-foreground italic">
                      Scan this with a phone to open the pre-filled login page for Court {sk}.
                    </p>
                  </DialogContent>
                </Dialog>
              ))}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center"><Loader2 className="animate-spin h-8 w-8 text-primary" /></div>}>
      <LoginContent />
    </Suspense>
  );
}
