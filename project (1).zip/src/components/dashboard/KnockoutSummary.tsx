"use client";

import { useTournament } from "@/lib/tournament-context";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Layers, Trophy } from "lucide-react";
import { cn } from "@/lib/utils";
import { Match } from "@/lib/types";

export function KnockoutSummary() {
  const { state } = useTournament();
  const knockoutMatches = state.matches.filter(m => m.stage === 'knockout');
  
  if (knockoutMatches.length === 0) return null;

  const roundGroups = [
    { 
      label: 'Round of 16', 
      codes: ['PQ1', 'PQ2', 'PQ3', 'PQ4', 'PQ5', 'PQ6', 'PQ7', 'PQ8'],
      aliases: ['PRE-QUARTER', 'ROUND OF 16', 'P-QUARTER']
    },
    { 
      label: 'Quarter-Final', 
      codes: ['Q1', 'Q2', 'Q3', 'Q4'],
      aliases: ['QUARTER', 'QUARTER-FINAL', 'QUARTERS']
    },
    { 
      label: 'Semi-Final', 
      codes: ['S1', 'S2'],
      aliases: ['SEMI', 'SEMI-FINAL', 'SEMIS']
    },
    { 
      label: 'Third Place', 
      codes: ['TP'],
      aliases: ['3RD PLACE', 'BRONZE']
    },
    { 
      label: 'Final', 
      codes: ['F'],
      aliases: ['FINAL', 'GOLD', 'CHAMPIONSHIP']
    }
  ];

  const normalize = (s: string) => s.trim().toUpperCase();

  return (
    <Card className="border-none shadow-sm bg-card/50 backdrop-blur-sm">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-xl font-bold flex items-center gap-2">
          <Layers className="text-secondary h-5 w-5" />
          Knockout Stage
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {roundGroups.map(round => {
            const roundMatches = knockoutMatches.filter(m => {
              if (!m.roundName) return false;
              const normalizedName = normalize(m.roundName);
              const matchesCode = round.codes.some(c => normalize(c) === normalizedName);
              const matchesAlias = round.aliases.some(a => normalizedName.includes(a));
              return matchesCode || matchesAlias;
            });
            
            if (roundMatches.length === 0) return null;

            const sortedMatches = [...roundMatches].sort((a, b) => {
              const nameA = a.roundName || '';
              const nameB = b.roundName || '';
              return nameA.localeCompare(nameB, undefined, { numeric: true, sensitivity: 'base' });
            });

            return (
              <div key={round.label} className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">{round.label}</span>
                  <div className="h-px bg-border flex-1" />
                </div>
                <div className="grid grid-cols-1 gap-2">
                  {sortedMatches.map(match => {
                    const t1 = state.teams.find(t => t.id === match.team1Id);
                    const t2 = state.teams.find(t => t.id === match.team2Id);
                    const completed = match.status === 'completed';
                    const isLive = match.status === 'live';
                    
                    const setsWon1 = match.gameScores.filter(g => Number(g.team1Score || 0) > Number(g.team2Score || 0)).length;
                    const setsWon2 = match.gameScores.filter(g => Number(g.team2Score || 0) > Number(g.team1Score || 0)).length;
                    
                    const team1Won = completed && setsWon1 > setsWon2;
                    const team2Won = completed && setsWon2 > setsWon1;

                    const scoreBreakdown = match.gameScores
                      .map(g => `${g.team1Score}-${g.team2Score}`)
                      .join(', ');

                    return (
                      <div key={match.id} className={cn(
                        "p-3 rounded-lg border bg-white transition-all",
                        isLive ? "ring-1 ring-secondary border-secondary/50 shadow-sm" : "border-border/50",
                        completed ? "opacity-90 bg-muted/5" : ""
                      )}>
                        <div className="flex items-center justify-between mb-2">
                          <Badge variant="default" className="text-[10px] font-black py-0 px-2 bg-primary text-white uppercase h-5">
                            {match.roundName || 'MATCH'}
                          </Badge>
                          <div className="flex items-center gap-2">
                            {isLive && (
                               <div className="flex items-center gap-1">
                                 <div className="w-1.5 h-1.5 rounded-full bg-secondary animate-pulse" />
                                 <span className="text-[9px] font-bold text-secondary uppercase">LIVE</span>
                               </div>
                            )}
                            <span className="text-[10px] font-mono text-muted-foreground">Court {match.court}</span>
                          </div>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex-1 space-y-1">
                            <div className={cn(
                              "flex justify-between items-center text-sm",
                              team1Won ? "font-black text-primary" : ""
                            )}>
                              <span className="truncate max-w-[140px] uppercase">{t1?.name || 'TBD'}</span>
                              <span className="font-mono font-black text-base">{setsWon1}</span>
                            </div>
                            <div className={cn(
                              "flex justify-between items-center text-sm",
                              team2Won ? "font-black text-primary" : ""
                            )}>
                              <span className="truncate max-w-[140px] uppercase">{t2?.name || 'TBD'}</span>
                              <span className="font-mono font-black text-base">{setsWon2}</span>
                            </div>
                          </div>
                          <div className="ml-4 border-l pl-4 flex flex-col items-end justify-center">
                            <span className="text-[8px] font-black text-muted-foreground uppercase mb-0.5 tracking-tighter">Sets Won</span>
                            {completed && (setsWon1 !== setsWon2) && <Trophy className="h-4 w-4 text-yellow-500" />}
                          </div>
                        </div>
                        <div className="mt-2 pt-2 border-t border-dashed flex justify-between items-center">
                           <span className="text-[8px] font-black text-muted-foreground uppercase tracking-widest">Game Scores</span>
                           <span className="text-[10px] font-mono font-bold text-muted-foreground italic">({scoreBreakdown})</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}