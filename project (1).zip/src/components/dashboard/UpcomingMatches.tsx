"use client";

import { useTournament } from "@/lib/tournament-context";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CalendarClock, MapPin } from "lucide-react";
import { cn } from "@/lib/utils";

export function UpcomingMatches() {
  const { state } = useTournament();
  const scheduledMatches = state.matches.filter(m => m.status === 'scheduled');

  if (scheduledMatches.length === 0) return null;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-2">
        <CalendarClock className="text-primary h-5 w-5" />
        <h2 className="text-xl font-bold font-headline">Upcoming Schedule</h2>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {scheduledMatches.map(match => {
          const team1 = state.teams.find(t => t.id === match.team1Id);
          const team2 = state.teams.find(t => t.id === match.team2Id);
          
          return (
            <Card key={match.id} className="border-none shadow-sm hover:shadow-md transition-all bg-white group overflow-hidden">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <Badge variant={match.stage === 'knockout' ? 'secondary' : 'outline'} className="text-[10px]">
                    {match.stage === 'knockout' ? match.roundName : `Group ${match.group}`}
                  </Badge>
                  <div className="flex items-center gap-3 text-muted-foreground">
                    <div className="flex items-center gap-1 text-[10px] font-bold">
                      <MapPin className="h-3 w-3" /> CRT {match.court}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <span className="font-bold text-sm block truncate uppercase">{team1?.name || 'TBD'}</span>
                    <span className="text-[9px] text-muted-foreground block truncate">{team1?.player1} & {team1?.player2}</span>
                  </div>
                  <div className="bg-muted px-2 py-0.5 rounded text-[8px] font-black shrink-0">VS</div>
                  <div className="flex-1 min-w-0 text-right">
                    <span className="font-bold text-sm block truncate uppercase">{team2?.name || 'TBD'}</span>
                    <span className="text-[9px] text-muted-foreground block truncate">{team2?.player1} & {team2?.player2}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
