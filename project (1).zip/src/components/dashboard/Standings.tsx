"use client";

import { useTournament } from "@/lib/tournament-context";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Trophy } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { GroupLetter, Team } from "@/lib/types";
import { sortTeams } from "@/lib/utils";

export function Standings() {
  const { state } = useTournament();
  
  const groups: GroupLetter[] = ['A', 'B', 'C', 'D'];

  const getSortedTeamsForGroup = (group: GroupLetter) => {
    const groupTeams = state.teams.filter(t => t.group === group);
    return sortTeams(groupTeams, state.matches);
  };

  return (
    <Card className="border-none shadow-sm bg-card/50 backdrop-blur-sm">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-xl font-bold flex items-center gap-2">
          <Trophy className="text-secondary h-5 w-5" />
          Round Robin Standings
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="A" className="w-full">
          <TabsList className="grid grid-cols-4 mb-4">
            {groups.map(g => (
              <TabsTrigger key={g} value={g}>Group {g}</TabsTrigger>
            ))}
          </TabsList>
          
          {groups.map(groupLetter => (
            <TabsContent key={groupLetter} value={groupLetter}>
              <div className="rounded-md border border-border/20 overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent border-b border-border/50 bg-muted/30">
                      <TableHead className="w-[50px] text-xs uppercase font-bold">Rank</TableHead>
                      <TableHead className="text-xs uppercase font-bold">Team</TableHead>
                      <TableHead className="text-center text-xs uppercase font-bold">W</TableHead>
                      <TableHead className="text-center text-xs uppercase font-bold">L</TableHead>
                      <TableHead className="text-right text-xs uppercase font-bold">Pts</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {getSortedTeamsForGroup(groupLetter).map((team, index) => (
                      <TableRow key={team.id} className="border-b border-border/10 transition-all hover:bg-primary/5">
                        <TableCell className="font-bold text-muted-foreground">
                          <div className="flex items-center gap-1">
                            {index < 4 && <div className="w-1 h-4 bg-secondary rounded-full" title="Advancing" />}
                            #{index + 1}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="font-semibold">{team.name}</div>
                          <div className="text-[10px] text-muted-foreground">{team.player1} & {team.player2}</div>
                        </TableCell>
                        <TableCell className="text-center font-medium">{team.wins}</TableCell>
                        <TableCell className="text-center text-muted-foreground">{team.losses}</TableCell>
                        <TableCell className="text-right font-bold text-primary">{team.points}</TableCell>
                      </TableRow>
                    ))}
                    {getSortedTeamsForGroup(groupLetter).length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-muted-foreground text-xs italic">
                          No teams assigned to Group {groupLetter} yet.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
              <div className="mt-2 text-[10px] text-muted-foreground italic flex items-center gap-1">
                <div className="w-1 h-3 bg-secondary rounded-full" /> Top 4 teams advance to Round of 16
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
}
