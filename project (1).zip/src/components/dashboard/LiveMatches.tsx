"use client";

import { useTournament } from "@/lib/tournament-context";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, Zap } from "lucide-react";
import { cn } from "@/lib/utils";

export function LiveMatches() {
  const { state } = useTournament();
  const liveMatches = state.matches.filter(m => m.status === 'live');

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-2">
        <Activity className="text-secondary h-5 w-5 animate-pulse" />
        <h2 className="text-xl font-bold font-headline">Live Matches</h2>
      </div>
      
      {liveMatches.length === 0 ? (
        <Card className="border-dashed border-2 bg-transparent">
          <CardContent className="flex flex-col items-center justify-center py-10 text-muted-foreground">
            <Zap className="h-8 w-8 mb-2 opacity-20" />
            <p>No matches currently in progress.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {liveMatches.map(match => {
            const team1 = state.teams.find(t => t.id === match.team1Id);
            const team2 = state.teams.find(t => t.id === match.team2Id);
            
            const team1WonLastPoint = match.lastPointTeamId === match.team1Id;
            const team2WonLastPoint = match.lastPointTeamId === match.team2Id;

            return (
              <Card key={match.id} className="relative overflow-hidden border-none shadow-md group hover:shadow-lg transition-all bg-white">
                <div className="absolute top-0 left-0 w-1 h-full bg-secondary" />
                <CardHeader className="pb-2 flex flex-row items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="bg-secondary/10 text-secondary border-none animate-pulse">LIVE</Badge>
                    <span className="text-[10px] font-bold uppercase tracking-tight text-muted-foreground">
                      {match.stage === 'knockout' ? (match.roundName || 'Elimination') : `Group ${match.group}`} • Court {match.court}
                    </span>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col gap-4">
                    <div className="flex justify-between items-center">
                      <div className="flex flex-col">
                        <span className={cn(
                          "text-lg font-bold transition-colors duration-300",
                          team1WonLastPoint ? "text-secondary font-black scale-105" : ""
                        )}>
                          {team1?.name}
                        </span>
                        <span className="text-xs text-muted-foreground">{team1?.player1} / {team1?.player2}</span>
                      </div>
                      <div className="flex gap-2">
                        {match.gameScores.map((g, i) => (
                          <span key={i} className={cn(
                            "w-8 h-8 flex items-center justify-center rounded-md font-bold text-sm",
                            g.team1Score > g.team2Score ? "bg-primary text-white" : "bg-muted"
                          )}>
                            {g.team1Score}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div className="h-px bg-border/50 w-full" />
                    
                    <div className="flex justify-between items-center">
                      <div className="flex flex-col">
                        <span className={cn(
                          "text-lg font-bold transition-colors duration-300",
                          team2WonLastPoint ? "text-secondary font-black scale-105" : ""
                        )}>
                          {team2?.name}
                        </span>
                        <span className="text-xs text-muted-foreground">{team2?.player1} / {team2?.player2}</span>
                      </div>
                      <div className="flex gap-2">
                        {match.gameScores.map((g, i) => (
                          <span key={i} className={cn(
                            "w-8 h-8 flex items-center justify-center rounded-md font-bold text-sm",
                            g.team2Score > g.team1Score ? "bg-primary text-white" : "bg-muted"
                          )}>
                            {g.team2Score}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
