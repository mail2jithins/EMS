export type GroupLetter = 'A' | 'B' | 'C' | 'D';

export type Team = {
  id: string;
  name: string;
  player1: string;
  player2: string;
  wins: number;
  losses: number;
  points: number;
  group?: GroupLetter;
};

export type GameScore = {
  team1Score: number;
  team2Score: number;
};

export type MatchStatus = 'scheduled' | 'live' | 'completed';
export type MatchStage = 'round-robin' | 'knockout';

export type Match = {
  id: string;
  team1Id: string;
  team2Id: string;
  stage: MatchStage;
  roundName?: string; // e.g., 'PQ1', 'Q1', etc.
  status: MatchStatus;
  gameScores: GameScore[];
  court?: string;
  recap?: string;
  group?: GroupLetter;
  lastPointTeamId?: string | null; // Tracks which team won the last point for UI highlighting
  activeGameIndex?: number; // Tracks which game is currently "Live" on TV
};

export type TournamentSettings = {
  maxTeams: number;
};

export type TournamentState = {
  teams: Team[];
  matches: Match[];
  settings: TournamentSettings;
};
