'use client';

import React, { createContext, useContext, useMemo } from 'react';
import { Team, Match, MatchStatus, TournamentSettings, GroupLetter, GameScore, TournamentState } from './types';
import { generateMatchRecap } from '@/ai/flows/generate-match-recaps';
import { 
  useCollection, 
  useDoc,
  useFirestore, 
  useUser,
  useMemoFirebase
} from '@/firebase';
import { 
  collection, 
  doc, 
  addDoc, 
  deleteDoc, 
  updateDoc,
  writeBatch,
  setDoc,
  getDocs,
  query
} from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';
import { sortTeams } from './utils';

interface TournamentContextType {
  state: TournamentState;
  loading: boolean;
  userRole: string | null;
  userEmail: string | null;
  addTeam: (team: Omit<Team, 'id' | 'wins' | 'losses' | 'points'>) => void;
  updateMatchScore: (matchId: string, team1Score: number, team2Score: number, gameIndex: number) => void;
  updateFullMatchScores: (matchId: string, gameScores: GameScore[]) => Promise<void>;
  setMatchStatus: (matchId: string, status: MatchStatus) => void;
  setActiveGame: (matchId: string, gameIndex: number) => void;
  generateRecap: (matchId: string) => Promise<void>;
  createMatch: (match: Omit<Match, 'id' | 'gameScores'>, numGames: number) => void;
  generateRoundRobinMatches: () => void;
  generateKnockoutPQMatches: () => void;
  generateKnockoutQuarterMatches: () => void;
  generateKnockoutSemiMatches: () => void;
  generateFinalsMatches: () => void;
  initializeTournament: (teams: Team[]) => void;
  deleteTeam: (teamId: string) => void;
  deleteMatch: (matchId: string) => void;
  updateSettings: (settings: Partial<TournamentSettings>) => void;
  resetTournament: () => Promise<void>;
  updateTeam: (teamId: string, updates: Partial<Team>) => Promise<void>;
  fixKnockoutIdentifiers: () => Promise<void>;
}

const TournamentContext = createContext<TournamentContextType | undefined>(undefined);

export function TournamentProvider({ children }: { children: React.ReactNode }) {
  const firestore = useFirestore();
  const { user, isUserLoading } = useUser();

  const userProfileRef = useMemoFirebase(() => 
    (firestore && user) ? doc(firestore, 'users', user.uid) : null, 
  [firestore, user]);
  
  const { data: profileData, isLoading: profileLoading } = useDoc<{role: string}>(userProfileRef);
  
  const userRole = useMemo(() => {
    if (!user) return 'viewer';
    if (profileLoading) return null;
    return profileData?.role || 'viewer';
  }, [user, profileData, profileLoading]);

  const userEmail = useMemo(() => user?.email || null, [user]);

  const teamsCollection = useMemoFirebase(() => firestore ? collection(firestore, 'teams') : null, [firestore]);
  const matchesCollection = useMemoFirebase(() => firestore ? collection(firestore, 'matches') : null, [firestore]);
  const settingsDocRef = useMemoFirebase(() => firestore ? doc(firestore, 'settings', 'tournament') : null, [firestore]);

  const { data: teamsData, isLoading: teamsLoading } = useCollection<Team>(teamsCollection);
  const { data: matchesData, isLoading: matchesLoading } = useCollection<Match>(matchesCollection);
  const { data: settingsData, isLoading: settingsLoading } = useDoc<TournamentSettings>(settingsDocRef);

  const state: TournamentState = useMemo(() => {
    const rawMatches = matchesData || [];
    const rawTeams = teamsData || [];

    const computedTeams = rawTeams.map(team => {
      let adjWins = Number(team.wins || 0);
      let adjLosses = Number(team.losses || 0);
      let adjPoints = Number(team.points || 0);

      let matchWins = 0;
      let matchLosses = 0;
      let matchPoints = 0;

      const teamMatches = rawMatches.filter(m => m.stage === 'round-robin' && (m.team1Id === team.id || m.team2Id === team.id));

      teamMatches.forEach(match => {
        const isTeam1 = match.team1Id === team.id;
        match.gameScores.forEach(game => {
          matchPoints += Number(isTeam1 ? (game.team1Score || 0) : (game.team2Score || 0));
        });

        if (match.status === 'completed') {
          const setsWon1 = match.gameScores.filter(g => Number(g.team1Score || 0) > Number(g.team2Score || 0)).length;
          const setsWon2 = match.gameScores.filter(g => Number(g.team2Score || 0) > Number(g.team1Score || 0)).length;

          if (setsWon1 > setsWon2) {
            isTeam1 ? matchWins++ : matchLosses++;
          } else if (setsWon2 > setsWon1) {
            isTeam1 ? matchLosses++ : matchWins++;
          }
        }
      });

      return {
        ...team,
        wins: adjWins + matchWins,
        losses: adjLosses + matchLosses,
        points: adjPoints + matchPoints,
        _matchWins: matchWins,
        _matchLosses: matchLosses,
        _matchPoints: matchPoints
      } as Team & { _matchWins: number, _matchLosses: number, _matchPoints: number };
    });

    return {
      teams: computedTeams,
      matches: rawMatches,
      settings: {
        maxTeams: settingsData?.maxTeams ?? 40
      }
    };
  }, [teamsData, matchesData, settingsData]);

  const loading = teamsLoading || matchesLoading || settingsLoading || isUserLoading || (user ? profileLoading : false);

  const addTeam = (team: Omit<Team, 'id' | 'wins' | 'losses' | 'points'>) => {
    if (!teamsCollection) return;
    const data = { ...team, wins: 0, losses: 0, points: 0 };
    addDoc(teamsCollection, data).catch(async (e) => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: 'teams',
        operation: 'create',
        requestResourceData: data
      }));
    });
  };

  const deleteTeam = (teamId: string) => {
    if (!firestore) return;
    deleteDoc(doc(firestore, 'teams', teamId)).catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: `teams/${teamId}`,
        operation: 'delete'
      }));
    });
  };

  const deleteMatch = (matchId: string) => {
    if (!firestore) return;
    deleteDoc(doc(firestore, 'matches', matchId)).catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: `matches/${matchId}`,
        operation: 'delete'
      }));
    });
  };

  const initializeTournament = async (teams: Team[]) => {
    if (!firestore) return;
    const batch = writeBatch(firestore);
    teams.forEach(t => {
      const { id, ...rest } = t;
      batch.set(doc(collection(firestore, 'teams')), rest);
    });
    batch.commit().catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: 'teams',
        operation: 'write'
      }));
    });
  };

  const createMatch = (matchData: Omit<Match, 'id' | 'gameScores'>, numGames: number) => {
    if (!matchesCollection) return;
    const data = {
      ...matchData,
      gameScores: Array.from({ length: numGames }, () => ({ team1Score: 0, team2Score: 0 })),
      activeGameIndex: 0
    };
    addDoc(matchesCollection, data).catch(async (e) => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: 'matches',
        operation: 'create',
        requestResourceData: data
      }));
    });
  };

  const generateRoundRobinMatches = () => {
    if (!firestore || !state.teams.length) return;
    const batch = writeBatch(firestore);
    const groups: GroupLetter[] = ['A', 'B', 'C', 'D'];
    const groupToCourt: Record<GroupLetter, string> = {
      'A': '1', 'B': '2', 'C': '3', 'D': '4'
    };

    groups.forEach(groupLetter => {
      const groupTeams = state.teams.filter(t => t.group === groupLetter);
      const court = groupToCourt[groupLetter];
      
      for (let i = 0; i < groupTeams.length; i++) {
        for (let j = i + 1; j < groupTeams.length; j++) {
          const team1 = groupTeams[i];
          const team2 = groupTeams[j];

          const exists = state.matches.find(m => 
            m.group === groupLetter && 
            ((m.team1Id === team1.id && m.team2Id === team2.id) || 
             (m.team1Id === team2.id && m.team2Id === team1.id))
          );

          if (!exists) {
            const matchRef = doc(collection(firestore, 'matches'));
            batch.set(matchRef, {
              team1Id: team1.id,
              team2Id: team2.id,
              stage: 'round-robin',
              status: 'scheduled',
              group: groupLetter,
              gameScores: [{ team1Score: 0, team2Score: 0 }],
              court: court,
              activeGameIndex: 0
            });
          }
        }
      }
    });

    batch.commit().catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: 'matches',
        operation: 'write'
      }));
    });
  };

  const generateKnockoutPQMatches = () => {
    if (!firestore || !state.teams.length) return;
    const batch = writeBatch(firestore);

    const groups: GroupLetter[] = ['A', 'B', 'C', 'D'];
    const sorted: Record<GroupLetter, Team[]> = {} as any;

    groups.forEach(g => {
      const groupTeams = state.teams.filter(t => t.group === g);
      sorted[g] = sortTeams(groupTeams, state.matches);
    });

    const createPQ = (t1: Team | undefined, t2: Team | undefined, code: string, court: string) => {
      if (!t1 || !t2) return;
      const exists = state.matches.find(m => m.stage === 'knockout' && m.roundName === code);
      if (!exists) {
        const matchRef = doc(collection(firestore, 'matches'));
        batch.set(matchRef, {
          team1Id: t1.id,
          team2Id: t2.id,
          stage: 'knockout',
          roundName: code,
          status: 'scheduled',
          gameScores: [
            { team1Score: 0, team2Score: 0 },
            { team1Score: 0, team2Score: 0 },
            { team1Score: 0, team2Score: 0 }
          ],
          court: court,
          activeGameIndex: 0
        });
      }
    };

    createPQ(sorted['A']?.[0], sorted['D']?.[3], 'PQ1', '1');
    createPQ(sorted['A']?.[1], sorted['D']?.[2], 'PQ2', '2');
    createPQ(sorted['A']?.[2], sorted['D']?.[1], 'PQ3', '3');
    createPQ(sorted['A']?.[3], sorted['D']?.[0], 'PQ4', '4');

    createPQ(sorted['B']?.[0], sorted['C']?.[3], 'PQ5', '1');
    createPQ(sorted['B']?.[1], sorted['C']?.[2], 'PQ6', '2');
    createPQ(sorted['B']?.[2], sorted['C']?.[1], 'PQ7', '3');
    createPQ(sorted['B']?.[3], sorted['C']?.[0], 'PQ8', '4');

    batch.commit().catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: 'matches',
        operation: 'write'
      }));
    });
  };

  const generateKnockoutQuarterMatches = () => {
    if (!firestore) return;
    const batch = writeBatch(firestore);

    const getMatchByCode = (code: string) => state.matches.find(m => m.stage === 'knockout' && m.roundName === code);
    
    const getWinnerId = (match: Match | undefined) => {
      if (!match || match.status !== 'completed') return "";
      const s1 = match.gameScores.filter(g => Number(g.team1Score || 0) > Number(g.team2Score || 0)).length;
      const s2 = match.gameScores.filter(g => Number(g.team2Score || 0) > Number(g.team1Score || 0)).length;
      return s1 > s2 ? match.team1Id : (s2 > s1 ? match.team2Id : "");
    };

    const pairings = [
      { code: 'Q1', p1: 'PQ1', p2: 'PQ8', court: '1' },
      { code: 'Q2', p1: 'PQ2', p2: 'PQ7', court: '2' },
      { code: 'Q3', p1: 'PQ3', p2: 'PQ6', court: '3' },
      { code: 'Q4', p1: 'PQ4', p2: 'PQ5', court: '4' },
    ];

    pairings.forEach(p => {
      const existing = state.matches.find(m => m.stage === 'knockout' && m.roundName === p.code);
      const w1 = getWinnerId(getMatchByCode(p.p1));
      const w2 = getWinnerId(getMatchByCode(p.p2));
      
      if (!existing) {
        const matchRef = doc(collection(firestore, 'matches'));
        batch.set(matchRef, {
          team1Id: w1,
          team2Id: w2,
          stage: 'knockout',
          roundName: p.code,
          status: 'scheduled',
          gameScores: [
            { team1Score: 0, team2Score: 0 },
            { team1Score: 0, team2Score: 0 },
            { team1Score: 0, team2Score: 0 }
          ],
          court: p.court,
          activeGameIndex: 0
        });
      } else {
        if ((!existing.team1Id && w1) || (!existing.team2Id && w2)) {
           batch.update(doc(firestore, 'matches', existing.id), {
             team1Id: existing.team1Id || w1,
             team2Id: existing.team2Id || w2
           });
        }
      }
    });

    batch.commit().catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: 'matches',
        operation: 'write'
      }));
    });
  };

  const generateKnockoutSemiMatches = () => {
    if (!firestore) return;
    const batch = writeBatch(firestore);

    const getMatchByCode = (code: string) => state.matches.find(m => m.stage === 'knockout' && m.roundName === code);
    
    const getWinnerId = (match: Match | undefined) => {
      if (!match || match.status !== 'completed') return "";
      const s1 = match.gameScores.filter(g => Number(g.team1Score || 0) > Number(g.team2Score || 0)).length;
      const s2 = match.gameScores.filter(g => Number(g.team2Score || 0) > Number(g.team1Score || 0)).length;
      return s1 > s2 ? match.team1Id : (s2 > s1 ? match.team2Id : "");
    };

    const pairings = [
      { code: 'S1', p1: 'Q1', p2: 'Q4', court: '1' },
      { code: 'S2', p1: 'Q2', p2: 'Q3', court: '2' },
    ];

    pairings.forEach(p => {
      const existing = state.matches.find(m => m.stage === 'knockout' && m.roundName === p.code);
      const w1 = getWinnerId(getMatchByCode(p.p1));
      const w2 = getWinnerId(getMatchByCode(p.p2));
      
      if (!existing) {
        const matchRef = doc(collection(firestore, 'matches'));
        batch.set(matchRef, {
          team1Id: w1,
          team2Id: w2,
          stage: 'knockout',
          roundName: p.code,
          status: 'scheduled',
          gameScores: [
            { team1Score: 0, team2Score: 0 },
            { team1Score: 0, team2Score: 0 },
            { team1Score: 0, team2Score: 0 }
          ],
          court: p.court,
          activeGameIndex: 0
        });
      } else {
        if ((!existing.team1Id && w1) || (!existing.team2Id && w2)) {
           batch.update(doc(firestore, 'matches', existing.id), {
             team1Id: existing.team1Id || w1,
             team2Id: existing.team2Id || w2
           });
        }
      }
    });

    batch.commit().catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: 'matches',
        operation: 'write'
      }));
    });
  };

  const generateFinalsMatches = () => {
    if (!firestore) return;
    const batch = writeBatch(firestore);

    const s1 = state.matches.find(m => m.stage === 'knockout' && m.roundName === 'S1');
    const s2 = state.matches.find(m => m.stage === 'knockout' && m.roundName === 'S2');

    const getWinnerId = (match: Match | undefined) => {
      if (!match || match.status !== 'completed') return "";
      const score1 = match.gameScores.filter(g => Number(g.team1Score || 0) > Number(g.team2Score || 0)).length;
      const score2 = match.gameScores.filter(g => Number(g.team2Score || 0) > Number(g.team1Score || 0)).length;
      return score1 > score2 ? match.team1Id : (score2 > score1 ? match.team2Id : "");
    };

    const getLoserId = (match: Match | undefined) => {
      if (!match || match.status !== 'completed') return "";
      const score1 = match.gameScores.filter(g => Number(g.team1Score || 0) > Number(g.team2Score || 0)).length;
      const score2 = match.gameScores.filter(g => Number(g.team2Score || 0) > Number(g.team1Score || 0)).length;
      return score1 > score2 ? match.team2Id : (score2 > score1 ? match.team1Id : "");
    };

    const w1 = getWinnerId(s1);
    const w2 = getWinnerId(s2);
    const l1 = getLoserId(s1);
    const l2 = getLoserId(s2);

    // Final match (F)
    const finalMatch = state.matches.find(m => m.stage === 'knockout' && m.roundName === 'F');
    if (!finalMatch) {
      const matchRef = doc(collection(firestore, 'matches'));
      batch.set(matchRef, {
        team1Id: w1,
        team2Id: w2,
        stage: 'knockout',
        roundName: 'F',
        status: 'scheduled',
        gameScores: [{ team1Score: 0, team2Score: 0 }, { team1Score: 0, team2Score: 0 }, { team1Score: 0, team2Score: 0 }],
        court: '1',
        activeGameIndex: 0
      });
    } else {
      if ((!finalMatch.team1Id && w1) || (!finalMatch.team2Id && w2)) {
        batch.update(doc(firestore, 'matches', finalMatch.id), {
          team1Id: finalMatch.team1Id || w1,
          team2Id: finalMatch.team2Id || w2
        });
      }
    }

    // Third Place match (TP)
    const tpMatch = state.matches.find(m => m.stage === 'knockout' && m.roundName === 'TP');
    if (!tpMatch) {
      const matchRef = doc(collection(firestore, 'matches'));
      batch.set(matchRef, {
        team1Id: l1,
        team2Id: l2,
        stage: 'knockout',
        roundName: 'TP',
        status: 'scheduled',
        gameScores: [{ team1Score: 0, team2Score: 0 }, { team1Score: 0, team2Score: 0 }, { team1Score: 0, team2Score: 0 }],
        court: '2',
        activeGameIndex: 0
      });
    } else {
      if ((!tpMatch.team1Id && l1) || (!tpMatch.team2Id && l2)) {
        batch.update(doc(firestore, 'matches', tpMatch.id), {
          team1Id: tpMatch.team1Id || l1,
          team2Id: tpMatch.team2Id || l2
        });
      }
    }

    batch.commit().catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: 'matches',
        operation: 'write'
      }));
    });
  };

  const updateMatchScore = (matchId: string, team1Score: number, team2Score: number, gameIndex: number) => {
    if (!firestore) return;
    const match = state.matches.find(m => m.id === matchId);
    if (!match) return;
    
    let lastPointTeamId = match.lastPointTeamId || null;
    const prevScore1 = Number(match.gameScores[gameIndex].team1Score || 0);
    const prevScore2 = Number(match.gameScores[gameIndex].team2Score || 0);

    if (Number(team1Score) > prevScore1) {
      lastPointTeamId = match.team1Id;
    } else if (Number(team2Score) > prevScore2) {
      lastPointTeamId = match.team2Id;
    }

    const newScores = [...match.gameScores];
    newScores[gameIndex] = { 
      team1Score: Number(team1Score), 
      team2Score: Number(team2Score) 
    };

    const matchRef = doc(firestore, 'matches', matchId);
    updateDoc(matchRef, { 
      gameScores: newScores,
      lastPointTeamId: lastPointTeamId,
      activeGameIndex: gameIndex 
    }).catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: `matches/${matchId}`,
        operation: 'update'
      }));
    });
  };

  const setActiveGame = (matchId: string, gameIndex: number) => {
    if (!firestore) return;
    updateDoc(doc(firestore, 'matches', matchId), { activeGameIndex: gameIndex }).catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: `matches/${matchId}`,
        operation: 'update'
      }));
    });
  };

  const updateFullMatchScores = async (matchId: string, gameScores: GameScore[]) => {
    if (!firestore) return;
    const match = state.matches.find(m => m.id === matchId);
    if (!match) return;

    const matchRef = doc(firestore, 'matches', matchId);
    
    const cleanScores = gameScores.map(g => ({
      team1Score: Number(g.team1Score),
      team2Score: Number(g.team2Score)
    }));

    // For manual updates, we default the active set to the last set with points or the last set in the array
    const lastPlayedIndex = cleanScores.reduce((acc, g, i) => (g.team1Score > 0 || g.team2Score > 0) ? i : acc, 0);

    const updatePayload = {
      gameScores: cleanScores,
      status: 'completed' as MatchStatus,
      lastPointTeamId: null,
      activeGameIndex: lastPlayedIndex
    };

    await updateDoc(matchRef, updatePayload).catch(async (error) => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: `matches/${matchId}`,
        operation: 'update',
        requestResourceData: updatePayload
      }));
      throw error;
    });
  };

  const setMatchStatus = (matchId: string, status: MatchStatus) => {
    if (!firestore) return;
    updateDoc(doc(firestore, 'matches', matchId), { status }).catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: `matches/${matchId}`,
        operation: 'update'
      }));
    });
  };

  const generateRecap = async (matchId: string) => {
    if (!firestore) return;
    const match = state.matches.find(m => m.id === matchId);
    if (!match) return;

    const team1 = state.teams.find(t => t.id === match.team1Id);
    const team2 = state.teams.find(t => t.id === match.team2Id);

    if (!team1 || !team2) return;

    try {
      const result = await generateMatchRecap({
        team1Name: team1.name,
        team2Name: team2.name,
        gameScores: match.gameScores
      });
      
      if (result && result.recap) {
        updateDoc(doc(firestore, 'matches', matchId), { recap: result.recap });
      }
    } catch (e) {
      console.warn("AI Recap generation failed.", e);
    }
  };

  const updateSettings = (updates: Partial<TournamentSettings>) => {
    if (!settingsDocRef) return;
    setDoc(settingsDocRef, updates, { merge: true }).catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: 'settings/tournament',
        operation: 'write',
        requestResourceData: updates
      }));
    });
  };

  const resetTournament = async () => {
    if (!firestore) return;
    const batch = writeBatch(firestore);
    
    const teamsSnap = await getDocs(collection(firestore, 'teams'));
    const matchesSnap = await getDocs(collection(firestore, 'matches'));
    
    teamsSnap.docs.forEach(d => batch.delete(d.ref));
    matchesSnap.docs.forEach(d => batch.delete(d.ref));
    
    await batch.commit().catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: 'batch-reset',
        operation: 'delete'
      }));
    });
  };

  const updateTeam = async (teamId: string, updates: Partial<Team>) => {
    if (!firestore) return;
    const teamRef = doc(firestore, 'teams', teamId);
    const finalUpdates: any = { ...updates };
    
    if ('wins' in finalUpdates) finalUpdates.wins = Number(finalUpdates.wins);
    if ('losses' in finalUpdates) finalUpdates.losses = Number(finalUpdates.losses);
    if ('points' in finalUpdates) finalUpdates.points = Number(finalUpdates.points);

    await updateDoc(teamRef, finalUpdates).catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: `teams/${teamId}`,
        operation: 'update',
        requestResourceData: finalUpdates
      }));
    });
  };

  const fixKnockoutIdentifiers = async () => {
    if (!firestore) return;
    const snap = await getDocs(collection(firestore, 'matches'));
    const knockoutMatches = snap.docs
      .map(d => ({ ...d.data(), id: d.id } as Match))
      .filter(m => m.stage === 'knockout')
      .sort((a, b) => a.id.localeCompare(b.id));

    if (knockoutMatches.length === 0) return;

    const batch = writeBatch(firestore);
    
    knockoutMatches.forEach((match, index) => {
      let newCode = match.roundName;
      if (index < 8) newCode = `PQ${index + 1}`;
      else if (index < 12) newCode = `Q${index - 7}`;
      else if (index < 14) newCode = `S${index - 11}`;
      else if (index === 14) newCode = 'TP';
      else if (index === 15) newCode = 'F';

      if (newCode && newCode !== match.roundName) {
        batch.update(doc(firestore, 'matches', match.id), { roundName: newCode });
      }
    });
    
    await batch.commit().catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: 'batch-fix-knockout',
        operation: 'update'
      }));
    });
  };

  return (
    <TournamentContext.Provider value={{ 
      state, 
      loading, 
      userRole,
      userEmail,
      addTeam, 
      updateMatchScore, 
      updateFullMatchScores,
      setMatchStatus, 
      setActiveGame,
      generateRecap, 
      createMatch, 
      generateRoundRobinMatches,
      generateKnockoutPQMatches,
      generateKnockoutQuarterMatches,
      generateKnockoutSemiMatches,
      generateFinalsMatches,
      initializeTournament, 
      deleteTeam, 
      deleteMatch,
      updateSettings,
      resetTournament,
      updateTeam,
      fixKnockoutIdentifiers
    }}>
      {children}
    </TournamentContext.Provider>
  );
}

export function useTournament() {
  const context = useContext(TournamentContext);
  if (context === undefined) {
    throw new Error('useTournament must be used within a TournamentProvider');
  }
  return context;
}
