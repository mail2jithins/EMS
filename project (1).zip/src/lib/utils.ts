import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { Team, Match } from './types'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Sorts teams according to tournament rules:
 * 1. Wins (Descending)
 * 2. Points (Descending)
 * 3. Head-to-Head result (if wins and points are equal)
 */
export function sortTeams(teams: Team[], matches: Match[]) {
  return [...teams].sort((a, b) => {
    // 1. Most Wins
    if ((Number(b.wins) || 0) !== (Number(a.wins) || 0)) {
      return (Number(b.wins) || 0) - (Number(a.wins) || 0);
    }
    
    // 2. Most Points (if wins are equal)
    if ((Number(b.points) || 0) !== (Number(a.points) || 0)) {
      return (Number(b.points) || 0) - (Number(a.points) || 0);
    }
    
    // 3. Tie-breaker: Head-to-Head result
    const headToHeadMatch = matches.find(m => 
      m.status === 'completed' && 
      ((m.team1Id === a.id && m.team2Id === b.id) || (m.team1Id === b.id && m.team2Id === a.id))
    );

    if (headToHeadMatch) {
      const setsWon1 = headToHeadMatch.gameScores.filter(g => Number(g.team1Score || 0) > Number(g.team2Score || 0)).length;
      const setsWon2 = headToHeadMatch.gameScores.filter(g => Number(g.team2Score || 0) > Number(g.team1Score || 0)).length;
      
      const aIsTeam1 = headToHeadMatch.team1Id === a.id;
      
      if (setsWon1 > setsWon2) return aIsTeam1 ? -1 : 1;
      if (setsWon2 > setsWon1) return aIsTeam1 ? 1 : -1;
    }

    return 0;
  });
}
